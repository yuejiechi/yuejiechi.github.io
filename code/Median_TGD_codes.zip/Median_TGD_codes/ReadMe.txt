1. 'Main.m' will call each script to generate all the figures. Since some experiments include Monte Carlo simulations, running all of them simultaneously may lead to a long wait. The codes are not optimized for speed.

2. Each script can be executed independently to generate the corresponding figures.
   Specifically,
   'Rectangle_est_random_matrix_outlier_fixnoutlier_changemr.m' generates figure 1(a).
   'Rectangle_est_random_matrix_outlier_fixmn_changeroutlier.m' generates figure 1(b).
   'Rectangle_est_random_matrix_outlier_noisy_comparison.m' generates figure 2.
   'Rectangle_est_random_matrix_outlier_noisy_convergence_rate.m' generates figure 3.
   'Tracking_Chlorine_Levels_comparison.m' generates figure 4.
   'CS_images_comparison.m' generates figure 5.

3. Due to numerical randomness, the generated figures might not be exactly the same with the ones in the paper.

4. The data used in Chlorine Concentration Recovery is obtained from EPANET software (https://www.epa.gov/water-research/epanet) and is available in 'PAPADIMITRIOU, S., SUN, J. & FALOUTSOS, C. (2005) Streaming pattern discovery in multiple time-series. in Proceedings of the 31st international conference on Very large data bases, pp. 697-708. VLDB Endowment'. ( http://www.cs.cmu.edu/afs/cs/project/spirit-1/www/).

5. The test image used in Compressed Sensing of Test Image is taken from the USC-SIPI image database (http://sipi.usc.edu/database/). 
