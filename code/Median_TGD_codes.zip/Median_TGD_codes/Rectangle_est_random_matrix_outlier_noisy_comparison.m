%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% figure 2
%% comparisons of average normalized estimate errors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

n_1 = 150;  % ground truth dimension
n_2 = 120;
r = 5;    % rank
outlier_perc = 0.05; % outlier percent vetcor

m_vector = [600:200:3000]; % number of measurements

X_ground_truth = randn(n_1, r); % ground truth
Y_ground_truth = randn(n_2, r);
M_ground_truth = X_ground_truth * Y_ground_truth';

total_trial = 10; % Monte Carlo
err_mediantruc_w_outlier_rightr_vec = zeros(1, length(m_vector)); % with outlier right rank
err_mediantruc_w_outlier_overr_vec = zeros(1, length(m_vector)); % with outlier overestimate rank r+1
err_vgd_w_outlier_vec = zeros(1, length(m_vector)); % with outlier
err_vgd_wout_outlier_vec = zeros(1, length(m_vector)); % without outlier


for m_index = 1:1:length(m_vector)
    m = m_vector(m_index);
    
    for trial = 1:1:total_trial

        %% generate sensing matrices
        Amatrix = zeros(n_1, n_2, m);
        Amatrix_vec = zeros(m, n_1*n_2);
        for A_index = 1:1:m
            A_temp = randn(n_1, n_2);
            Amatrix(:, :, A_index) = A_temp;
            A_temp_vec = A_temp(:);
            Amatrix_vec(A_index, :) = A_temp_vec';
        end

        M_ground_truth_vec = M_ground_truth(:);
        y_pure = Amatrix_vec * M_ground_truth_vec;

        %% add outliers
        outlier_num = round(m * outlier_perc);
        outlier_index = randperm(m, outlier_num)';

        outlier_vec = (10^2) * norm(M_ground_truth, 'fro') * randn(outlier_num, 1);             % outlier value 
        y_outlier = y_pure;
        y_outlier(outlier_index) = outlier_vec; % measurements with outliers

        %% add bounded noise
        [SVL_groung_truth, SS_ground_truth, SVR_grouth_truth] = svd(M_ground_truth);
        SS_ground_truth_vec = diag(SS_ground_truth);
        bdnoise_vector = 0.05 * SS_ground_truth_vec(r) * (2*rand(m,1) - 1);
        y_outlier_noise = y_outlier + bdnoise_vector;
        y_noise = y_pure + bdnoise_vector;

        %% median TWF with median truncation with outlier right rank
        %% parameter setting
        alpha_y = 12;
        alpha_h = 6;
        regu_lambda = 0.249587;
        mu = 0.4;
        iter_num = 10^4;
        [X_hat_mediantruc_w_outlier_rightr, Y_hat_mediantruc_w_outlier_rightr, initial_err_mediantruc_w_outlier_rightr, iter_err_mediantruc_w_outlier_rightr]...
        = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                                      y_outlier_noise, Amatrix, Amatrix_vec,...
                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
        err_mediantruc_w_outlier_rightr = norm(X_hat_mediantruc_w_outlier_rightr*Y_hat_mediantruc_w_outlier_rightr' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_mediantruc_w_outlier_rightr_vec(1, m_index) = err_mediantruc_w_outlier_rightr_vec(1, m_index) + err_mediantruc_w_outlier_rightr;
  
        % print
        % fprintf('mTWF mediantruc_w_outlier_rightr m = %d, trial = %d, err = %.8f\n\n', m, trial, err_mediantruc_w_outlier_rightr);

        
        %% median TWF with median truncation with outlier over rank r+1
        %% parameter setting
        alpha_y = 12;
        alpha_h = 6;
        regu_lambda = 0.249587;
        mu = 0.4;
        iter_num = 10^4;
        [X_hat_mediantruc_w_outlier_overr, Y_hat_mediantruc_w_outlier_overr, initial_err_mediantruc_w_outlier_overr, iter_err_mediantruc_w_outlier_overr]...
        = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r+1,...
                                                      y_outlier_noise, Amatrix, Amatrix_vec,...
                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
        err_mediantruc_w_outlier_overr = norm(X_hat_mediantruc_w_outlier_overr*Y_hat_mediantruc_w_outlier_overr' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_mediantruc_w_outlier_overr_vec(1, m_index) = err_mediantruc_w_outlier_overr_vec(1, m_index) + err_mediantruc_w_outlier_overr;
  
        % print
        % fprintf('mTWF mediantruc_w_outlier_overr m = %d, trial = %d, err = %.8f\n\n', m, trial, err_mediantruc_w_outlier_overr);

        
        %% WF (vgd) with outlier
        regu_lambda = 0.25;
        mu = 0.4;
        iter_num = 10^4;
        [X_hat_vgd_w_outlier, Y_hat_vgd_w_outlier, initial_err_vgd_w_outlier, iter_err_vgd_w_outlier]...
        = Alg_rectangle_randmatrix_vgd(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                       y_outlier_noise, Amatrix, Amatrix_vec,...
                                       regu_lambda, mu, iter_num);
        err_vgd_w_outlier = norm(X_hat_vgd_w_outlier*Y_hat_vgd_w_outlier' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_vgd_w_outlier_vec(1, m_index) = err_vgd_w_outlier_vec(1, m_index) + err_vgd_w_outlier;
  
        % print
        % fprintf('WF vgd_w_outlier m = %d, trial = %d, err = %.8f\n\n', m, trial, err_vgd_w_outlier);
        
        
        %% WF (vgd) without outlier
        regu_lambda = 0.25;
        mu = 0.4;
        iter_num = 10^4;
        [X_hat_vgd_wout_outlier, Y_hat_vgd_wout_outlier, initial_err_vgd_wout_outlier, iter_err_vgd_wout_outlier]...
        = Alg_rectangle_randmatrix_vgd(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                       y_noise, Amatrix, Amatrix_vec,...
                                       regu_lambda, mu, iter_num);
        err_vgd_wout_outlier = norm(X_hat_vgd_wout_outlier*Y_hat_vgd_wout_outlier' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_vgd_wout_outlier_vec(1, m_index) = err_vgd_wout_outlier_vec(1, m_index) + err_vgd_wout_outlier;
  
        % print
        % fprintf('WF vgd_wout_outlier m = %d, trial = %d, err = %.8f\n\n', m, trial, err_vgd_wout_outlier);

        % save Rectangle_est_random_matrix_outlier_noisy_comparison
    end
end


%% plot


figure;
semilogy(m_vector, err_mediantruc_w_outlier_rightr_vec/total_trial,'r-o');
hold on;
semilogy(m_vector, err_mediantruc_w_outlier_overr_vec/total_trial,'b-*');
hold on;
semilogy(m_vector, err_vgd_w_outlier_vec/total_trial,'m-+');
hold on;
semilogy(m_vector, err_vgd_wout_outlier_vec/total_trial,'k-x');

grid on;
xlim([m_vector(4), m_vector(end)]);
xlabel('Number of measurements (m)');
ylabel('Average normalized estimate error');

legend('Median-truncated gradient descent with r', 'Median-truncated gradient descent with r+1',...
       'Vanilla gradient descent with outliers', 'Vanilla gradient descent without outliers');
