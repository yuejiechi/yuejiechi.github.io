%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 
%% main
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

%% figure 1(a)

%Rectangle_est_random_matrix_outlier_fixnoutlier_changemr;


%% figure 1(b)

%Rectangle_est_random_matrix_outlier_fixmn_changeroutlier;


%% figure 2

%Rectangle_est_random_matrix_outlier_noisy_comparison;


%% figure 3

%Rectangle_est_random_matrix_outlier_noisy_convergence_rate;


%% figure 4

Tracking_Chlorine_Levels_comparison;


%% figure 5

CS_images_comparison;


