%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% figure 3
%% comparisons of convergence rate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

n_1 = 150;  % ground truth dimension
n_2 = 120;
r = 5;    % rank
m = 2400; % number of measurements

outlier_perc_vector = [0, 0.01, 0.05, 0.1]; % outlier percent vetcor

X_ground_truth = randn(n_1, r); % ground truth
Y_ground_truth = randn(n_2, r);
M_ground_truth = X_ground_truth * Y_ground_truth';

pick_length = 500;
err_mediantruc_w_outlier_rightr_mat = zeros(length(outlier_perc_vector), pick_length); 
err_mediantruc_w_outlier_overr_mat = zeros(length(outlier_perc_vector), pick_length); 
err_vgd_w_outlier_mat = zeros(length(outlier_perc_vector), pick_length); 
err_vgd_wout_outlier_mat = zeros(length(outlier_perc_vector), pick_length); 

%% generate sensing matrices
Amatrix = zeros(n_1, n_2, m);
Amatrix_vec = zeros(m, n_1*n_2);
for A_index = 1:1:m
    A_temp = randn(n_1, n_2);
    Amatrix(:, :, A_index) = A_temp;
    A_temp_vec = A_temp(:);
    Amatrix_vec(A_index, :) = A_temp_vec';
end

M_ground_truth_vec = M_ground_truth(:);
y_pure = Amatrix_vec * M_ground_truth_vec;

%% generate bounded noise
[SVL_groung_truth, SS_ground_truth, SVR_grouth_truth] = svd(M_ground_truth);
SS_ground_truth_vec = diag(SS_ground_truth);
bdnoise_vector = 0.05 * SS_ground_truth_vec(r) * (2*rand(m,1) - 1);
y_noise = y_pure + bdnoise_vector;
        
for outlier_perc_index = 1:1:length(outlier_perc_vector)
    outlier_perc = outlier_perc_vector(outlier_perc_index);
        
        %% add outliers
        outlier_num = round(m * outlier_perc);
        outlier_index = randperm(m, outlier_num)';

        outlier_vec = (10^2) * norm(M_ground_truth, 'fro') * randn(outlier_num, 1);             % outlier value 
        y_outlier = y_pure;
        y_outlier(outlier_index) = outlier_vec; % measurements with outliers

        %% add bounded noise
        y_outlier_noise = y_outlier + bdnoise_vector;
       

        %% median TWF with median truncation with outlier right rank
        %% parameter setting
        alpha_y = 12;
        alpha_h = 6;
        regu_lambda = 0.249587;
        mu = 0.4;
        iter_num = pick_length;
        [X_hat_mediantruc_w_outlier_rightr, Y_hat_mediantruc_w_outlier_rightr, initial_err_mediantruc_w_outlier_rightr, iter_err_mediantruc_w_outlier_rightr]...
        = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                                      y_outlier_noise, Amatrix, Amatrix_vec,...
                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
        err_mediantruc_w_outlier_rightr = norm(X_hat_mediantruc_w_outlier_rightr*Y_hat_mediantruc_w_outlier_rightr' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_mediantruc_w_outlier_rightr_mat(outlier_perc_index, :) = iter_err_mediantruc_w_outlier_rightr(1:pick_length);
  
        % print
        % fprintf('mTWF mediantruc_w_outlier_rightr outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_mediantruc_w_outlier_rightr);

        
        %% median TWF with median truncation with outlier over rank r+1
        %% parameter setting
        alpha_y = 12;
        alpha_h = 6;
        regu_lambda = 0.249587;
        mu = 0.4;
        iter_num = pick_length;
        [X_hat_mediantruc_w_outlier_overr, Y_hat_mediantruc_w_outlier_overr, initial_err_mediantruc_w_outlier_overr, iter_err_mediantruc_w_outlier_overr]...
        = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r+1,...
                                                      y_outlier_noise, Amatrix, Amatrix_vec,...
                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
        err_mediantruc_w_outlier_overr = norm(X_hat_mediantruc_w_outlier_overr*Y_hat_mediantruc_w_outlier_overr' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_mediantruc_w_outlier_overr_mat(outlier_perc_index, :) = iter_err_mediantruc_w_outlier_overr(1:pick_length);
  
        % print
        % fprintf('mTWF mediantruc_w_outlier_overr outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_mediantruc_w_outlier_overr);

        
        %% WF (vgd) with outlier
        regu_lambda = 0.25;
        mu = 0.4;
        iter_num = pick_length;
        [X_hat_vgd_w_outlier, Y_hat_vgd_w_outlier, initial_err_vgd_w_outlier, iter_err_vgd_w_outlier]...
        = Alg_rectangle_randmatrix_vgd(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                       y_outlier_noise, Amatrix, Amatrix_vec,...
                                       regu_lambda, mu, iter_num);
        err_vgd_w_outlier = norm(X_hat_vgd_w_outlier*Y_hat_vgd_w_outlier' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_vgd_w_outlier_mat(outlier_perc_index, :) = iter_err_vgd_w_outlier(1:pick_length);
  
        % print
        % fprintf('WF vgd_w_outlier outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_vgd_w_outlier);
        
        
        %% WF (vgd) without outlier
        regu_lambda = 0.25;
        mu = 0.4;
        iter_num = pick_length;
        [X_hat_vgd_wout_outlier, Y_hat_vgd_wout_outlier, initial_err_vgd_wout_outlier, iter_err_vgd_wout_outlier]...
        = Alg_rectangle_randmatrix_vgd(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                       y_noise, Amatrix, Amatrix_vec,...
                                       regu_lambda, mu, iter_num);
        err_vgd_wout_outlier = norm(X_hat_vgd_wout_outlier*Y_hat_vgd_wout_outlier' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_vgd_wout_outlier_mat(outlier_perc_index, :) = iter_err_vgd_wout_outlier(1:pick_length);
  
        % print
        % fprintf('WF vgd_wout_outlier outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_vgd_wout_outlier);

        % save Rectangle_est_random_matrix_outlier_noisy_convergence_rate
   
end

%% plot


index = 1;
figure;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_rightr_mat(index,:),'r-o', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_overr_mat(index,:),'b-*', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_w_outlier_mat(index,:),'m-+', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_wout_outlier_mat(index,:),'k-x', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);

grid on;
xlim([1,200]);
xlabel('Iteration');
ylabel('Normalized estimate error');
legend('Median-truncated gradient descent with r', 'Median-truncated gradient descent with r+1',...
       'Vanilla gradient descent with outliers', 'Vanilla gradient descent without outliers');


index = 2;
figure;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_rightr_mat(index,:),'r-o', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_overr_mat(index,:),'b-*', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_w_outlier_mat(index,:),'m-+', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_wout_outlier_mat(index,:),'k-x', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);

grid on;
xlim([1,200]);
xlabel('Iteration');
ylabel('Normalized estimate error');
legend('Median-truncated gradient descent with r', 'Median-truncated gradient descent with r+1',...
       'Vanilla gradient descent with outliers', 'Vanilla gradient descent without outliers');


index = 4;
figure;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_rightr_mat(index,:),'r-o', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_mediantruc_w_outlier_overr_mat(index,:),'b-*', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_w_outlier_mat(index,:),'m-+', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);
hold on;
semilogy([1:1:pick_length], err_vgd_wout_outlier_mat(index,:),'k-x', 'LineWidth',2,'MarkerSize',8,'MarkerIndices',1:10:pick_length);

grid on;
xlim([1,200]);
xlabel('Iteration');
ylabel('Normalized estimate error');
legend('Median-truncated gradient descent with r', 'Median-truncated gradient descent with r+1',...
       'Vanilla gradient descent with outliers', 'Vanilla gradient descent without outliers');
   
