%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% figure 1(a)
%% success rate with respect to the number of measurements and the rank
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

n_1 = 150;  % ground truth dimension
n_2 = 120;
outlier_perc = 0.05; % outlier percent

r_vector = [1:1:10];    % rank vector
m_vector = [500:300:3200]; % number of measurements

total_trial = 10; % Monte Carlo
succ_crit = 10^(-6); % successful criterton

succ_rate_mat_mediantruc = zeros(length(r_vector), length(m_vector));

for r_index = 1:1:length(r_vector)
    r = r_vector(r_index);
    
    X_ground_truth = randn(n_1, r); % ground truth
    Y_ground_truth = randn(n_2, r);
    M_ground_truth = X_ground_truth * Y_ground_truth';
    M_ground_truth_vec = M_ground_truth(:);
        
    for m_index = 1:1:length(m_vector)
        m = m_vector(m_index);
            
        for trial = 1:1:total_trial

            %% generate sensing matrices
            Amatrix = zeros(n_1, n_2, m);
            Amatrix_vec = zeros(m, n_1*n_2);
            for A_index = 1:1:m
                A_temp = randn(n_1, n_2);
                Amatrix(:, :, A_index) = A_temp;
                A_temp_vec = A_temp(:);
                Amatrix_vec(A_index, :) = A_temp_vec';
            end

            y_pure = Amatrix_vec * M_ground_truth_vec;

            %% add outliers
            outlier_num = round(m * outlier_perc);  % outlier number 
            outlier_index = randperm(m, outlier_num)';

            outlier_vec = (10^2) * norm(M_ground_truth, 'fro') * randn(outlier_num, 1);             % outlier value 
            y_outlier = y_pure;
            y_outlier(outlier_index) = outlier_vec; % measurements with outliers


            %% median TWF with median truncation
            %% parameter setting
            alpha_y = 12;
            alpha_h = 6;
            regu_lambda = 0.249587;
            mu = 0.4;
            iter_num = 10^4;
            [X_hat_mediantruc, Y_hat_mediantruc, initial_err_mediantruc, iter_err_mediantruc] = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                                                                      y_outlier, Amatrix, Amatrix_vec,...
                                                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
            est_err_mediantruc = norm(X_hat_mediantruc*Y_hat_mediantruc' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
            if (est_err_mediantruc <= succ_crit)
                succ_rate_mat_mediantruc(r_index, m_index) = succ_rate_mat_mediantruc(r_index, m_index) + 1;
            end

            % print
            % fprintf('mTWF mediantruc  rank r = %d, m = %d, trial = %d, err = %.8f\n\n', r, m, trial, est_err_mediantruc);
            
            
            % save Rectangle_est_random_matrix_outlier_fixnoutlier_changemr_outlier005
            
         end
    end
end


%% plot


figure;
imagesc(m_vector, r_vector, succ_rate_mat_mediantruc/total_trial);
colormap(gray);
xlabel('Number of measurements (m)');
ylabel('Rank (r)');
colorbar;
axis xy;

hold on;
m_theory_vec = m_vector;
r_theory_vec = (1 - outlier_perc) * m_theory_vec / (n_1 + n_2);
plot(m_theory_vec, r_theory_vec, 'r');
legend('Theoretical limit');




