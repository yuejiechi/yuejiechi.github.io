%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Coveraicne Estimation via Median TWF with outliers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% algorithm
%% input
%%    X_gt  ground truth factor
%%    Y_gt  ground truth factor
%%    n_1  ground truth matrix dimension
%%    n_2  ground truth matrix dimension
%%    r  ground truth matrix rank (estimate)
%%    y  measurement vector
%%    Amatrix  sensing matrices
%%    Amatrix_vec  sensing matrices vectorization
%%    alpha_y  threshold in initial
%%    alpha_h  threshold in indicator
%%    regu_lambda  regularization parameter
%%    mu_t  step size
%%    iter_num  iteration number
%% output
%%    U_hat  U estimate
%%    V_hat  V estimate
%%    initial_err  estimate error in initial
%%    iter_err  estimate error vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X_hat, Y_hat, initial_err, iter_err_vec] = Alg_rectangle_randmatrix_outlier_median_TWF(X_gt, Y_gt, n_1, n_2, r,...
                                                                                      y, Amatrix, Amatrix_vec,...
                                                                                      alpha_y, alpha_h, regu_lambda, mu_t, iter_num)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% algorithm

%% parameters
m = length(y);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialization
y_tr = y.* ( abs(y) <= alpha_y * median(abs(y)) );  %% y after truncation

K_mat = zeros(n_1, n_2);
for K_index = 1:1:m
    K_mat = K_mat + y_tr(K_index, 1) * Amatrix(:, :, K_index);
end
K_mat = (1/m) * K_mat;

[SVL_K, SS_K, SVR_K] = svd(K_mat);
SS_K_vec = diag(SS_K);
U_0 = SVL_K(:,1:r) * diag(sqrt(SS_K_vec(1:r)));
V_0 = SVR_K(:,1:r) * diag(sqrt(SS_K_vec(1:r)));

initial_err = norm(U_0*V_0' - X_gt*Y_gt', 'fro') / norm(X_gt*Y_gt', 'fro');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Loop
U_t = U_0;
V_t = V_0;

mu_U_t = mu_t / SS_K_vec(1);
mu_V_t = mu_t / SS_K_vec(1);

iter_err_vec = zeros(1, iter_num);

for iter_index = 1:1:iter_num
   
    %% median truncation
    UVt = U_t * V_t';
    UVt_vec = UVt(:);
    y_UVt = Amatrix_vec * UVt_vec;  
    med_t = median(abs( y - y_UVt ));   
    Eh  =  abs( y - y_UVt ) <= alpha_h * med_t;
%     Eh_num = sum(Eh);
%     Eh = ones(m, 1);
    
   %% gradient
   grad_matrix = zeros(n_1, n_2);
   for grad_index = 1:1:m
       grad_matrix = grad_matrix + Eh(grad_index, 1) *...
                              (y_UVt(grad_index, 1) - y(grad_index, 1)) * Amatrix(:, :, grad_index);
   end
   %% add regularization
   UV_diff_t = U_t'*U_t - V_t'*V_t;
   grad_matrix_U = (1/2/m) * grad_matrix * V_t + regu_lambda * U_t * UV_diff_t;
   grad_matrix_V = (1/2/m) * grad_matrix' * U_t + regu_lambda * V_t * (-UV_diff_t);

   %% update
   U_t = U_t - mu_U_t * grad_matrix_U;
   V_t = V_t - mu_V_t * grad_matrix_V;
   
   iter_err_vec(iter_index) = norm(U_t*V_t' - X_gt*Y_gt', 'fro') / norm(X_gt*Y_gt', 'fro');
   
%    fprintf('rectangle matrix est, iter_index = %d, est_err = %.8f \n\n', iter_index, iter_err_vec(iter_index));
   
%    %% stop criterion
%    if( iter_index >= 2 )
%        if ( abs(iter_err(iter_index) - iter_err(iter_index - 1)) <= 10^(-12) )
%            break;
%        end
%    end
end

%% return estimates
X_hat = U_t;
Y_hat = V_t;