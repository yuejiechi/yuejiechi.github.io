%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% figure 5
%% compressive sensing of test image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

%% image reading 
pixel_type = 2^8;
image_name = '7.1.08.tiff';
raw_image = imread(image_name);

image_re_size = 128;
raw_image = imresize(raw_image, [image_re_size, image_re_size]);
if length(size(raw_image)) == 3
    raw_image = double(rgb2gray(raw_image));
else
    raw_image = double(raw_image);
end

figure;
imshow(raw_image/(pixel_type-1));

M_ground_truth = raw_image;    
image_size = size(M_ground_truth);

n_1 = image_size(1);  % ground truth dimension
n_2 = image_size(2);
r = 8;    % rank
m = 4600; % number of measurements

outlier_perc_vector = [0, 0.01, 0.05, 0.1]; % outlier percent vetcor

[image_X, image_S, image_Y] = svd(M_ground_truth);
image_s_vec = diag(image_S);
X_svd_app = image_X(:,1:r) * diag(image_s_vec(1:r).^(1/2)); % ground truth
Y_svd_app = image_Y(:,1:r) * diag(image_s_vec(1:r).^(1/2));
M_svd_app = X_svd_app * Y_svd_app';
err_svd_app = norm(M_svd_app - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');

figure;
imshow(M_svd_app/(pixel_type-1));

X_ground_truth = M_ground_truth;
Y_ground_truth = eye(n_2);

%% error
pick_length = 10000;
err_mediantruc_w_outlier_rightr_mat = zeros(length(outlier_perc_vector), pick_length); 
err_vgd_w_outlier_mat = zeros(length(outlier_perc_vector), pick_length); 


%% estimate
X_hat_mediantruc_w_outlier_rightr_mat = zeros(n_1, r, length(outlier_perc_vector)); 
Y_hat_mediantruc_w_outlier_rightr_mat = zeros(n_2, r, length(outlier_perc_vector));
X_hat_vgd_w_outlier_mat = zeros(n_1, r, length(outlier_perc_vector)); 
Y_hat_vgd_w_outlier_mat = zeros(n_2, r, length(outlier_perc_vector));


%% generate sensing matrices
Amatrix = zeros(n_1, n_2, m);
Amatrix_vec = zeros(m, n_1*n_2);
for A_index = 1:1:m
    A_temp = randn(n_1, n_2);
    Amatrix(:, :, A_index) = A_temp;
    A_temp_vec = A_temp(:);
    Amatrix_vec(A_index, :) = A_temp_vec';
end

M_ground_truth_vec = M_ground_truth(:);
y_pure = Amatrix_vec * M_ground_truth_vec;

%% generate bounded noise
bdnoise_vector = zeros(m, 1); 

        
for outlier_perc_index = 1:1:length(outlier_perc_vector)
    outlier_perc = outlier_perc_vector(outlier_perc_index);
        
        %% add outliers
        outlier_num = round(m * outlier_perc);
        outlier_index = randperm(m, outlier_num)';

        outlier_vec = (10^2) * norm(M_ground_truth, 'fro') * randn(outlier_num, 1);             % outlier value  
        y_outlier = y_pure;
        y_outlier(outlier_index) = outlier_vec; % measurements with outliers

        %% add bounded noise
        y_outlier_noise = y_outlier + bdnoise_vector;
       

        %% median TWF with median truncation with outlier right rank
        %% parameter setting
        alpha_y = 12;
        alpha_h = 6;
        regu_lambda = 0.249587;
        mu = 0.2;
        iter_num = pick_length;
        [X_hat_mediantruc_w_outlier_rightr, Y_hat_mediantruc_w_outlier_rightr, initial_err_mediantruc_w_outlier_rightr, iter_err_mediantruc_w_outlier_rightr]...
        = Alg_rectangle_randmatrix_outlier_median_TWF(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                                      y_outlier_noise, Amatrix, Amatrix_vec,...
                                                      alpha_y, alpha_h, regu_lambda, mu, iter_num);
        err_mediantruc_w_outlier_rightr = norm(X_hat_mediantruc_w_outlier_rightr*Y_hat_mediantruc_w_outlier_rightr' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_mediantruc_w_outlier_rightr_mat(outlier_perc_index, :) = iter_err_mediantruc_w_outlier_rightr(1:pick_length);
  
        X_hat_mediantruc_w_outlier_rightr_mat(:, :, outlier_perc_index) = X_hat_mediantruc_w_outlier_rightr;
        Y_hat_mediantruc_w_outlier_rightr_mat(:, :, outlier_perc_index) = Y_hat_mediantruc_w_outlier_rightr;
        % print
        % fprintf('mTWF mediantruc_w_outlier_rightr outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_mediantruc_w_outlier_rightr);

                
        %% WF (vgd) with outlier
        regu_lambda = 0.25;
        mu = 0.2;
        iter_num = pick_length;
        [X_hat_vgd_w_outlier, Y_hat_vgd_w_outlier, initial_err_vgd_w_outlier, iter_err_vgd_w_outlier]...
        = Alg_rectangle_randmatrix_vgd(X_ground_truth, Y_ground_truth, n_1, n_2, r,...
                                       y_outlier_noise, Amatrix, Amatrix_vec,...
                                       regu_lambda, mu, iter_num);
        err_vgd_w_outlier = norm(X_hat_vgd_w_outlier*Y_hat_vgd_w_outlier' - M_ground_truth, 'fro') / norm(M_ground_truth, 'fro');
        
        err_vgd_w_outlier_mat(outlier_perc_index, :) = iter_err_vgd_w_outlier(1:pick_length);
  
        X_hat_vgd_w_outlier_mat(:, :, outlier_perc_index) = X_hat_vgd_w_outlier;
        Y_hat_vgd_w_outlier_mat(:, :, outlier_perc_index) = Y_hat_vgd_w_outlier;
        % print
        % fprintf('WF vgd_w_outlier outlier_perc = %.2f, err = %.8f\n\n', outlier_perc, err_vgd_w_outlier);
        
        
%         save CS_images_comparison
   
end

M_est_median_s0 = X_hat_mediantruc_w_outlier_rightr_mat(:,:,1)*Y_hat_mediantruc_w_outlier_rightr_mat(:,:,1)';
M_est_median_s001 = X_hat_mediantruc_w_outlier_rightr_mat(:,:,2)*Y_hat_mediantruc_w_outlier_rightr_mat(:,:,2)';

M_est_vgd_s0 = X_hat_vgd_w_outlier_mat(:,:,1)*Y_hat_vgd_w_outlier_mat(:,:,1)';
M_est_vgd_s001 = X_hat_vgd_w_outlier_mat(:,:,2)*Y_hat_vgd_w_outlier_mat(:,:,2)';

%% plot
figure;
imshow(M_est_vgd_s0/(pixel_type-1));

figure;
imshow(M_est_vgd_s001/(pixel_type-1));

figure;
imshow(M_est_median_s0/(pixel_type-1));

figure;
imshow(M_est_median_s001/(pixel_type-1));
