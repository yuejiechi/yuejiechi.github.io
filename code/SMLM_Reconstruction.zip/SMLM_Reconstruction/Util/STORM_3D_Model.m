function w = STORM_3D_Model(curve_para, z)
% PURPOSE:
% This function is to generate the PSF width according to the defocusing
% curve parameters and z location.
%---------------------------------------------------
% USAGE:
% w = STORM_3D_Model(curve_para, z)
%---------------------------------------------------
% INPUTS:
% curve_para:   defocusing curve parameters
% z:            z location
%---------------------------------------------------
% OUTPUTS:
% w:            PSF width
%---------------------------------------------------
% REFERENCE:
% Huang, Jiaqing, Mingzhai Sun, Kristyn Gumpper, Yuejie Chi, and
% Jianjie Ma. "3D multifocus astigmatism and compressed sensing (3D MACS)
% based superresolution reconstruction."
% Biomedical optics express 6, no. 3 (2015): 902-917.
%---------------------------------------------------

% 3D MACS paper eq. (2).
w = curve_para(1) * sqrt(...
    1 + ((z - curve_para(3)) / curve_para(2)) .^ 2 +...
    curve_para(4) * ((z - curve_para(3)) / curve_para(2)) .^ 3 +...
    curve_para(5) * ((z - curve_para(3)) / curve_para(2)) .^ 4);