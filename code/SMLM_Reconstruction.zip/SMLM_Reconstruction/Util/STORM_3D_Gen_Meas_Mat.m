function A = STORM_3D_Gen_Meas_Mat(maxz, stacknum, width, height, div, curve_para)
% PURPOSE:
% This function is to generate the measurement matrix for 3D single
% camera STORM image reconstruction.
%---------------------------------------------------
% USAGE:
% A = STORM_3D_Gen_Meas_Mat(maxz, stacknum, width, height, div, curve_para)
%---------------------------------------------------
% INPUTS:
% maxz:         maximum z location of emitter (um)
% stacknum:     number of z-dimensional layers in
%               generated measurement matrix
% width:        image width
% height:       image height
% div:          upsampling factor in x y-dimension
% curve_para:   defocusing curve parameters
%---------------------------------------------------
% OUTPUTS:
% A:            generated measurement matrix
%---------------------------------------------------

zlist = linspace(-maxz, maxz, stacknum);
% meshgrid of original image size
[xx, yy] = meshgrid(1 : width, 1 : height);
% meshgrid of upsampled image size
[xxx, yyy, zzz] = meshgrid(0.5 + 1 / div / 2 : 1 / div : width + 0.5 - 1 / div / 2,...
    0.5 + 1 / div / 2 : 1 / div : height + 0.5 - 1 / div / 2, zlist);
xx_r = xx(:); yy_r = yy(:);
xxx_r = xxx(:); yyy_r = yyy(:); zzz_r = zzz(:);

A = zeros(width * height, size(xxx_r, 1));

% iterate through all upsampled grid points
for i = 1 : size(xxx_r, 1)
    % get the width in x and y dimension
    wx = STORM_3D_Model(curve_para(:, 1), zzz_r(i));
    wy = STORM_3D_Model(curve_para(:, 2), zzz_r(i));
    % generate measurement on a given point
    A(:, i) = 1 / 4 *...
        (erf((xx_r + 0.5 - xxx_r(i)) / sqrt(2) / wx) -...
        erf((xx_r - 0.5 - xxx_r(i)) / sqrt(2) / wx)) .*...
        (erf((yy_r + 0.5 - yyy_r(i)) / sqrt(2) / wy) -...
        erf((yy_r - 0.5 - yyy_r(i)) / sqrt(2) / wy));
end