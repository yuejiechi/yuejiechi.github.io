function [FP, FN, DIFF] = STORM_3D_Precision_Cal(clustCent,...
    emitterList, minDist_xy, minDist_z)
% PURPOSE:
% Calculate the precision, false-negative and false-positive
% rate of given clustCent using emitterList as the ground truth.
%---------------------------------------------------
% USAGE:
% [FP, FN, precision] = STORM_3D_Precision_Cal(clustCent,...
%   emitterList, minDist_xy, minDist_z)
%---------------------------------------------------
% INPUTS:
% clustCent:    reconstructed center position
% emitterList:  true position
% minDist_xy:   minimum distance in xy plane
% minDist_z:    minimum distance in z plane
%---------------------------------------------------
% OUTPUTS:
% FP:           false positive rate
% FN:           false negative rate
% DIFF:         difference in x, y and z direction of matched pair
%---------------------------------------------------

if isempty(clustCent) && isempty(emitterList)
    FP = 0;
    FN = 0;
    DIFF = [];
elseif isempty(clustCent)
    FP = 0;
    FN = 1;
    DIFF = [];
elseif isempty(emitterList)
    FP = 1;
    FN = 0;
    DIFF= [];
else
    DIFF = [];
    clustCent = clustCent(:, 1 : 3);
    d1 = size(emitterList, 1);
    d2 = size(clustCent, 1);
    dist_xy = pdist2(clustCent(:, 1 : 2), emitterList(:, 1 : 2));
    dist_z = pdist2(clustCent(:, 3), emitterList(:, 3));
    emitter_stat = zeros(d1);
    PP = 0;
    for i = 1 : d2
        list = dist_xy(i, :) < minDist_xy & dist_z(i, :) < minDist_z;
        subdist_xy = dist_xy(i, list);
        subdist_xy = sort(subdist_xy);
        for j = 1 : length(subdist_xy)
            idx = find(dist_xy(i, :) == subdist_xy(j));
            if emitter_stat(idx) == 0
                emitter_stat(idx) = 1;
                PP = PP + 1;
                DIFF = [DIFF; emitterList(idx, 1 : 3) - clustCent(i, 1 : 3)];
                break;
            end
        end
    end
    FN = (d1 - PP) / d1;
    FP = (d2 - PP) / d1;
end