function A = Gen_Meas_From_3D_Coord(coord_list, height, width, curve_para)
% PURPOSE:
% Generate measurement matrix based on input 3D emitter coordinate.
%---------------------------------------------------
% USAGE:
% A = Gen_Meas_From_3D_Coord(coord_list, height, width, curve_para)
%---------------------------------------------------
% INPUTS:
% coord_list:   list of input coordinate
% height:       image height
% width:        image width
% curve_para:   defocusing curve parameters
%---------------------------------------------------
% OUTPUTS:
% A:            generated measurement matrix
%---------------------------------------------------

[xx, yy] = meshgrid(1 : width, 1 : height);
xx_r = xx(:); yy_r = yy(:);

A = zeros(height * width, size(coord_list, 1));

% iterate through all input coordinate
for i = 1 : size(coord_list, 1)
    % get the width in x and y dimension
    wx = STORM_3D_Model(curve_para(:, 1), coord_list(i, 3));
    wy = STORM_3D_Model(curve_para(:, 2), coord_list(i, 3));
    % generate measurement on a given point
    A(:, i) = 1 / 4 *...
        (erf((xx_r + 0.5 - coord_list(i, 1)) / sqrt(2) / wx) -...
        erf((xx_r - 0.5 - coord_list(i, 1)) / sqrt(2) / wx)) .*...
        (erf((yy_r + 0.5 - coord_list(i, 2)) / sqrt(2) / wy) -...
        erf((yy_r - 0.5 - coord_list(i, 2)) / sqrt(2) / wy));
end