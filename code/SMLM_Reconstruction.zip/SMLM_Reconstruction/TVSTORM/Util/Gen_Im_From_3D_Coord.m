function im = Gen_Im_From_3D_Coord(coord_list, I_list, height, width, curve_para)
% PURPOSE:
% Generate image based on input 3D emitter coordinate and intensity.
%---------------------------------------------------
% USAGE:
% im = Gen_Im_From_Coord(coord_list, I_list, height, width, curve_para)
%---------------------------------------------------
% INPUTS:
% coord_list:   list of input coordinate
% I_list:       list of input intensity
% height:       image height
% width:        image width
% curve_para:   defocusing curve parameters
%---------------------------------------------------
% OUTPUTS:
% im:           generated image
%---------------------------------------------------

[xx, yy] = meshgrid(1 : width, 1 : height);
xx_r = xx(:); yy_r = yy(:);

im = zeros(height * width, 1);

% iterate through all input coordinate
for i = 1 : size(coord_list, 1)
    % get the width in x and y dimension
    wx = STORM_3D_Model(curve_para(:, 1), coord_list(i, 3));
    wy = STORM_3D_Model(curve_para(:, 2), coord_list(i, 3));
    % generate measurement on a given point
    im = im + I_list(i) / 4 *...
        (erf((xx_r + 0.5 - coord_list(i, 1)) / sqrt(2) / wx) -...
        erf((xx_r - 0.5 - coord_list(i, 1)) / sqrt(2) / wx)) .*...
        (erf((yy_r + 0.5 - coord_list(i, 2)) / sqrt(2) / wy) -...
        erf((yy_r - 0.5 - coord_list(i, 2)) / sqrt(2) / wy));
end