function p = STORM_dsigma_dz(curve_para, z)
% PURPOSE:
% This function is to calculate the partial derivative of sigma with
% respect to z.
%---------------------------------------------------
% USAGE:
% p = STORM_dsigma_dz(curve_para, z)
%---------------------------------------------------
% INPUTS:
% curve_para:   defocusing curve parameters
% z:            z location
%---------------------------------------------------
% OUTPUTS:
% w:            PSF width
%---------------------------------------------------

p = curve_para(1) * ...
    (2 * (z - curve_para(3)) / curve_para(2) +...
    3 * curve_para(4) * ((z - curve_para(3)) / curve_para(2)) ^ 2 +...
    4 * curve_para(5) * ((z - curve_para(3)) / curve_para(2)) ^ 3) /...
    (2 * sqrt(1 + ((z - curve_para(3)) / curve_para(2)) .^ 2 +...
    curve_para(4) * ((z - curve_para(3)) / curve_para(2)) .^ 3 +...
    curve_para(5) * ((z - curve_para(3)) / curve_para(2)) .^ 4));