function [coord_list, I_list, bg] = Coordinate_Descent_3D(...
    coord_list, I_list, bg, im, height, width, curve_para, maxz)
% PURPOSE:
% Gradient descent on 3D coordinate and weight refinement.
%---------------------------------------------------
% USAGE:
% [coord_list, I_list, bg] = Coordinate_Descent_3D(...
%   coord_list, I_list, bg, height, width, curve_para, maxz)
%---------------------------------------------------
% INPUTS:
% coord_list:   list of input coordinate
% I_list:       list of input intensity
% bg:           background photon
% height:       image height
% width:        image width
% curve_para:   defocusing curve parameters
% maxz:         maximum z location of emitter (um)
%---------------------------------------------------
% OUTPUTS:
% coord_list:   list of output coordinate
% I_list:       list of output intensity
% bg:           output background photon
%---------------------------------------------------

%%
iter = 1;
max_iter = 300;

[xx, yy] = meshgrid(1 : width, 1 : height);
xx_r = xx(:); yy_r = yy(:);

A = Gen_Meas_From_3D_Coord(coord_list, height, width, curve_para);

res_list = [];
%%
while iter < max_iter
    mu = A * I_list + bg;
    res_list(iter) = sum(mu - im .* log(mu + 1e-5));
    %% background descent
    grad_bg = sum((mu - im) ./ (mu + 1e-5));
    % backtracking
    alpha = 0.5;
    epsilon = 1;
    if grad_bg > 0
        epsilon = min(epsilon, bg / grad_bg);
    end
    df = -1e-6 * norm(grad_bg) ^ 2;
    mu = A * I_list + bg;
    fc = sum(mu - im .* log(mu + 1e-5));

    bg_temp = bg - epsilon * grad_bg;
    mu_base = A * I_list;
    mu = mu_base + bg_temp;

    while sum(mu - im .* log(mu + 1e-5)) > fc + epsilon * df
        epsilon = epsilon * max(alpha, 0.1);
        alpha = alpha * 0.8;
        if epsilon < 1e-10
            epsilon = 0;
            break;
        end
        bg_temp = bg - epsilon * grad_bg;
        mu = mu_base + bg_temp;
    end
    bg = bg - epsilon * grad_bg;
    
    for i = 1 : size(coord_list, 1)
        %% intensity descent
        sigmax = STORM_3D_Model(curve_para(:, 1), coord_list(i, 3));
        sigmay = STORM_3D_Model(curve_para(:, 2), coord_list(i, 3));
        temp_xx = erf((xx + 0.5 - coord_list(i, 1)) / sqrt(2) / sigmax) -...
            erf((xx - 0.5 - coord_list(i, 1)) / sqrt(2) / sigmax);
        temp_yy = erf((yy + 0.5 - coord_list(i, 2)) / sqrt(2) / sigmay) -...
            erf((yy - 0.5 - coord_list(i, 2)) / sqrt(2) / sigmay);
        
        grad_I = sum((mu - im) ./ (mu + 1e-5) .* temp_xx(:) .* temp_yy(:));
        
        % backtracking
        alpha = 0.5;
        epsilon = 1000;
        if grad_I > 0
            epsilon = min(epsilon, I_list(i) / grad_I);
        end
        df = -1e-6 * norm(grad_I) ^ 2;
        mu = A * I_list + bg;
        fc = sum(mu - im .* log(mu + 1e-5));
        
        I = I_list(i) - epsilon * grad_I;
        mu_base = A(:, [1 : i - 1, i + 1 : end]) * I_list([1 : i - 1, i + 1 : end], :);
        mu = mu_base + A(:, i) * I + bg;
        
        while sum(mu - im .* log(mu + 1e-5)) > fc + epsilon * df
            epsilon = epsilon * max(alpha, 0.1);
            alpha = alpha * 0.8;
            if epsilon < 1e-10
                epsilon = 0;
                break;
            end
            I = I_list(i) - epsilon * grad_I;
            mu = mu_base + A(:, i) * I + bg;
        end
        I_list(i) = I_list(i) - epsilon * grad_I;
        %% x y coord descent
        mu = A * I_list + bg;
        
        d_mu_x = I_list(i) / (2 * sqrt(2 * pi) * sigmax) *...
            (exp(-(xx - 0.5 - coord_list(i, 1)) .^ 2 / (2 * sigmax ^ 2)) -...
            exp(-(xx + 0.5 - coord_list(i, 1)) .^ 2 / (2 * sigmax ^ 2))) .* temp_yy;
        d_mu_y = I_list(i) / (2 * sqrt(2 * pi) * sigmay) * temp_xx .*...
            (exp(-(yy - 0.5 - coord_list(i, 2)) .^ 2 / (2 * sigmay ^ 2)) -...
            exp(-(yy + 0.5 - coord_list(i, 2)) .^ 2 / (2 * sigmay ^ 2)));
        
        grad_xy = [sum((mu - im) ./ (mu + 1e-5) .* d_mu_x(:)),...
            sum((mu - im) ./ (mu + 1e-5) .* d_mu_y(:))];
        
        % backtracking
        alpha = 0.5;
        epsilon = 1e-1;
        df = -1e-6 * norm(grad_xy) ^ 2;
        mu = A * I_list + bg;
        fc = sum(mu - im .* log(mu + 1e-5));
        
        coord = coord_list(i, 1 : 2) - epsilon * grad_xy;
        mu_base = A(:, [1 : i - 1, i + 1 : end]) * I_list([1 : i - 1, i + 1 : end], :);
        meas_col = 1 / 4 *...
            (erf((xx_r + 0.5 - coord(1)) / sqrt(2) / sigmax) -...
            erf((xx_r - 0.5 - coord(1)) / sqrt(2) / sigmax)) .*...
            (erf((yy_r + 0.5 - coord(2)) / sqrt(2) / sigmay) -...
            erf((yy_r - 0.5 - coord(2)) / sqrt(2) / sigmay));
        mu = mu_base + meas_col * I_list(i) + bg;
        
        while sum(mu - im .* log(mu + 1e-5)) > fc + epsilon * df
            epsilon = epsilon * max(alpha, 0.1);
            alpha = alpha * 0.8;
            if epsilon < 1e-10
                epsilon = 0;
                meas_col = A(:, i);
                break;
            end
            coord = coord_list(i, 1 : 2) - epsilon * grad_xy;
            meas_col = 1 / 4 *...
                (erf((xx_r + 0.5 - coord(1)) / sqrt(2) / sigmax) -...
                erf((xx_r - 0.5 - coord(1)) / sqrt(2) / sigmax)) .*...
                (erf((yy_r + 0.5 - coord(2)) / sqrt(2) / sigmay) -...
                erf((yy_r - 0.5 - coord(2)) / sqrt(2) / sigmay));
            mu = mu_base + meas_col * I_list(i) + bg;
        end
        A(:, i) = meas_col;
        coord_list(i, 1 : 2) = coord_list(i, 1 : 2) - epsilon * grad_xy;
        %% z coord descent
        temp_xx = erf((xx + 0.5 - coord_list(i, 1)) / sqrt(2) / sigmax) -...
            erf((xx - 0.5 - coord_list(i, 1)) / sqrt(2) / sigmax);
        temp_yy = erf((yy + 0.5 - coord_list(i, 2)) / sqrt(2) / sigmay) -...
            erf((yy - 0.5 - coord_list(i, 2)) / sqrt(2) / sigmay);
        d_mu_sigmax = I_list(i) / (2 * sqrt(2 * pi) * sigmax ^ 2) *...
            (exp(-(xx - 0.5 - coord_list(i, 1)) .^ 2 / 2 / sigmax ^ 2) .*...
            (xx - 0.5 - coord_list(i, 1)) -...
            exp(-(xx + 0.5 - coord_list(i, 1)) .^ 2 / 2 / sigmax ^ 2) .*...
            (xx + 0.5 - coord_list(i, 1))) .* temp_yy;
        d_mu_sigmay = I_list(i) / (2 * sqrt(2 * pi) * sigmay ^ 2) * temp_xx .*...
            (exp(-(yy - 0.5 - coord_list(i, 2)) .^ 2 / 2 / sigmay ^ 2) .*...
            (yy - 0.5 - coord_list(i, 2)) -...
            exp(-(yy + 0.5 - coord_list(i, 2)) .^ 2 / 2 / sigmay ^ 2) .*...
            (yy + 0.5 - coord_list(i, 2)));
        
        d_sigmax_z = STORM_dsigma_dz(curve_para(:, 1), coord_list(i, 3));
        d_sigmay_z = STORM_dsigma_dz(curve_para(:, 2), coord_list(i, 3));
        d_mu_z = d_mu_sigmax * d_sigmax_z + d_mu_sigmay * d_sigmay_z;
        
        % backtracking
        mu = A * I_list + bg;
        grad_z = sum((mu - im) ./ (mu + 1e-5) .* d_mu_z(:));
        
        fc = sum(mu - im .* log(mu + 1e-5));
        alpha = 0.5;
        epsilon = 1e-1;
        df = -1e-3 * norm(grad_z) ^ 2;
        
        coord = coord_list(i, :);
        if grad_z > 0
            epsilon = min(epsilon, (maxz + coord_list(i, 3)) / grad_z);
        else
            epsilon = min(epsilon, (maxz - coord_list(i, 3)) / -grad_z);
        end
        epsilon = max(epsilon, 1e-10);
        
        coord(3) = coord_list(i, 3) - epsilon * grad_z;
        mu_base = A(:, [1 : i - 1, i + 1 : end]) * I_list([1 : i - 1, i + 1 : end], :);
        sigmax = STORM_3D_Model(curve_para(:, 1), coord(3));
        sigmay = STORM_3D_Model(curve_para(:, 2), coord(3));
        meas_col = 1 / 4 *...
            (erf((xx_r + 0.5 - coord(1)) / sqrt(2) / sigmax) -...
            erf((xx_r - 0.5 - coord(1)) / sqrt(2) / sigmax)) .*...
            (erf((yy_r + 0.5 - coord(2)) / sqrt(2) / sigmay) -...
            erf((yy_r - 0.5 - coord(2)) / sqrt(2) / sigmay));
        mu = mu_base + meas_col * I_list(i) + bg;
        
        while sum(mu - im .* log(mu + 1e-5)) > fc + epsilon * df
            epsilon = epsilon * max(alpha, 0.1);
            alpha = alpha * 0.8;
            if epsilon < 1e-10
                epsilon = 0;
                meas_col = A(:, i);
                break;
            end
            coord(3) = coord_list(i, 3) - epsilon * grad_z;
            sigmax = STORM_3D_Model(curve_para(:, 1), coord(3));
            sigmay = STORM_3D_Model(curve_para(:, 2), coord(3));
            meas_col = 1 / 4 *...
                (erf((xx_r + 0.5 - coord(1)) / sqrt(2) / sigmax) -...
                erf((xx_r - 0.5 - coord(1)) / sqrt(2) / sigmax)) .*...
                (erf((yy_r + 0.5 - coord(2)) / sqrt(2) / sigmay) -...
                erf((yy_r - 0.5 - coord(2)) / sqrt(2) / sigmay));
            mu = mu_base + meas_col * I_list(i) + bg;
        end
        %%
        A(:, i) = meas_col;
        coord_list(i, 3) = coord_list(i, 3) - epsilon * grad_z;
    end
    
    if iter > 1 && res_list(iter - 1) - res_list(iter) < 1e-2
        break;
    end
    iter = iter + 1;
end