%% This is to test the performance of TVSTORM vs. CSSTORM on simulated
%  data under different densities
clear all;
close all;
clc;

pixelsize = 0.075;      % camera pixel size (um)
width = 18;             % image width (pixel)
height = 18;            % image height (pixel)
g_noise = 0;            % gaussian noise level (photons/pixel)
photons = 500;          % average photon number
maxz = 0.4;             % maximum z position (um)

%% Generate measurement matrix
disp('Generating measurement matrix ...');
div1 = 8;                % upsampling factor in x y dimension
stacknum1 = 9;           % upsampling factor in z dimension
% 3D psf parameters measured in real system settings
data = load('three_d_parameter.mat');
curve_para = reshape(data.curve_para(:, 1, :), 5, 2);
% measurement matrix for CS
A1 = STORM_3D_Gen_Meas_Mat(maxz, stacknum1, width, height, div1, curve_para);

% measurement matrix for ADCG
div2 = 2;                % upsampling factor in x y dimension
stacknum2 = 5;           % upsampling factor in z dimension
A2 = STORM_3D_Gen_Meas_Mat(maxz, stacknum2, width, height, div2, curve_para);

%%
density_list = [0.1, 0.3, 0.6, 1:9];
iters = 1000;

im_list = cell(length(density_list), iters);
emitter_List = cell(length(density_list), iters);

FN_list = zeros(length(density_list), iters);
FP_list = zeros(length(density_list), iters);
t_list = zeros(length(density_list), iters);
DIFF_list = cell(length(density_list),1);

FN_list2 = zeros(length(density_list), iters);
FP_list2 = zeros(length(density_list), iters);
t_list2 = zeros(length(density_list), iters);
DIFF_list2 = cell(length(density_list),1);

minDist_xy = 1; % this is in pixel
minDist_z = 0.1; % this is in um

for density_id = 1 : length(density_list)
    density = density_list(density_id);
    disp(['processing density ', num2str(density), '...']);
    for id = 1 : iters
        [im, emitterList] = STORM_3D_Simulation(density, pixelsize,...
            width, height, g_noise, photons, maxz, curve_para);

        %% CSSTORM
        % start time
        t_start = tic;
        
        thresh = 150;
        finalList = STORM_3D_CS(A1, im, height, width, div1, stacknum1, maxz, thresh);
        
        % end time
        t1 = toc(t_start);
        
        % calculate performance
        [FP, FN, DIFF] = STORM_3D_Precision_Cal(finalList, emitterList, minDist_xy, minDist_z);
        
        FN_list(density_id, id) = FN;
        FP_list(density_id, id) = FP;
        t_list(density_id, id) = t1;
        DIFF_list{density_id} = [DIFF_list{density_id}; DIFF];
        
        %% TVSTORM
        % start time
        t_start = tic;
        
        thresh = 150; % threshold for the reconstructed image
        ns = 0.9;
        [finalList2, I_list2] = TVSTORM_3D(A2, im, height, width,...
            div2, stacknum2, maxz, ns, curve_para, thresh);
        finalList2 = finalList2(I_list2 > 2 * thresh, :);
        
        % end time
        t2 = toc(t_start);
        
        % calculate performance
        [FP, FN, DIFF] = STORM_3D_Precision_Cal(finalList2, emitterList, minDist_xy, minDist_z);
        
        FN_list2(density_id, id) = FN;
        FP_list2(density_id, id) = FP;
        t_list2(density_id, id) = t2;
        DIFF_list2{density_id} = [DIFF_list2{density_id}; DIFF];
        
        im_list{density_id, id} = im;
        emitter_List{density_id, id} = emitterList;
    end
end

%% Display
set(0,'DefaultAxesFontSize',12);

figure('Position', [100, 100, 430, 450]);
% Identified
FN_CSSTORM = mean(FN_list, 2);
FN_TVSTORM = mean(FN_list2, 2);

subplot(2,2,1); hold on;
plot(density_list,(1 - FN_CSSTORM)' .* density_list, 'bo-');
plot(density_list,(1 - FN_TVSTORM)'.* density_list, 'r^-');
plot([0, max(density_list)], [0, max(density_list)], 'k--');
box on;
legend('CSSTORM', 'TVSTORM');
axis equal;
axis([0, max(density_list), 0, max(density_list)]);
ylabel('Identified Density (emitters/\mum^2)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
ax.YTick = 0 : 9;
grid on;

% FP
FP_CSSTORM = mean(FP_list, 2);
FP_TVSTORM = mean(FP_list2, 2);

subplot(2, 2, 2); hold on;
plot(density_list, FP_CSSTORM, 'bo-');
plot(density_list, FP_TVSTORM, 'r^-');
xlim([0, max(density_list)]);
ylim([0 0.2]);
box on;
legend('CSSTORM', 'TVSTORM');
ylabel('False Discovery Rate');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% Precision
DIFF_CSSTORM = zeros(size(DIFF_list, 1), 3);
DIFF_TVSTORM = zeros(size(DIFF_list2, 1), 3);
for i = 1 : size(DIFF_list, 1)
    DIFF_CSSTORM(i, :) = std(DIFF_list{i});
end
for i = 1 : size(DIFF_list2, 1)
    DIFF_TVSTORM(i, :) = std(DIFF_list2{i});
end

subplot(2, 2, 3); hold on;
plot(density_list,sqrt((DIFF_CSSTORM(:, 1) * 75) .^ 2 + ...
    (DIFF_CSSTORM(:, 2) * 75) .^ 2 * 75 + (DIFF_CSSTORM(:, 3) * 1000) .^ 2), ...
    'bo-');
plot(density_list,sqrt((DIFF_TVSTORM(:, 1) * 75) .^ 2 + ...
    (DIFF_TVSTORM(:, 2) * 75) .^ 2 * 75 + (DIFF_TVSTORM(:, 3) * 1000) .^ 2), ...
    'r^-');
box on;
legend('CSSTORM', 'TVSTORM');
xlim([0, max(density_list)]);
ylabel('Precision (nm)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% time
t_CSSTORM = mean(t_list, 2);
t_TVSTORM = mean(t_list2, 2);
subplot(2, 2, 4);
semilogy(density_list, t_CSSTORM, 'bo-'); hold on;
semilogy(density_list, t_TVSTORM, 'r^-');
box on;
legend('CSSTORM', 'TVSTORM');
xlim([0, max(density_list)]);
ylabel('Execution Time (s)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;