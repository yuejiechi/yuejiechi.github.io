%% This is to test the TVSTORM algorithm with 2D STORM image reconstruction
close all;
clear;
clc;

%% Set up the parameters
density = 5;            % emitter density (fluorophores per um^2)
pixelsize = 0.075;      % camera pixel size (um)
width = 18;             % image width (pixel)
height = 18;            % image height (pixel)
g_noise = 0;            % gaussian noise level (photons/pixel)
photons = 500;         % average photon number
sigma = 1.5;            % standard deviation of system PSF (pixel)

%% Generate measurement matrix
disp('Generating measurement matrix ...');
div1 = 8; % zoom factor
% measurement matrix for CS
A1 = STORM_2D_Gen_Meas_Mat(width, height, div1, sigma);

% measurement matrix for ADCG
div2 = 2;
A2 = STORM_2D_Gen_Meas_Mat(width, height, div2, sigma);

%% Generate simulated image
disp('Generating simulated image ...');
[im, emitterList] = STORM_2D_Simulation(density, pixelsize, ...
    width, height, g_noise, photons, sigma);

%% Compressed sensing on the image
thresh = 100;
ns = 1.5;
di_wid = 1;
t1 = tic;
[clustCent1, xm] = STORM_2D_CS(A1, im, height, width, div1, thresh, ns, di_wid);
disp(['CS processing time: ', num2str(toc(t1)), ' seconds']);

%% TVSTORM
ns = 0.9;
thresh = 150;
t1 = tic;
[clustCent2, I_list2] = TVSTORM_2D(A2, im, height, width, sigma, div2, ns, thresh);
disp(['TVSTORM processing time: ', num2str(toc(t1)), ' seconds']);

%% Display
figure;
im = reshape(im, height, width);
imagesc(im); colormap gray; axis equal; axis off; hold on;
plot(emitterList(:, 1), emitterList(:, 2), 'kx', 'MarkerSize', 7, 'LineWidth', 1.5);
plot(clustCent1(:, 1), clustCent1(:, 2), 'ro', 'MarkerSize', 7, 'LineWidth', 1.5);
plot(clustCent2(:, 1), clustCent2(:, 2), 'bo', 'MarkerSize', 7, 'LineWidth', 1.5);