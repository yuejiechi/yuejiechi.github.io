%% This is to test the performance of TVSTORM vs. CSSTORM on simulated
%  data under different densities
clear all;
close all;
clc;

pixelsize = 0.075;      % camera pixel size (um)
width = 18;             % image width (pixel)
height = 18;            % image height (pixel)
g_noise = 0;            % gaussian noise level (photons/pixel)
photons = 500;          % average photon number
sigma = 1.5;            % standard deviation of system PSF (pixel)

%% Generate measurement matrix
disp('Generating measurement matrix ...');
div1 = 8;                % upsampling factor in x y dimension
% measurement matrix for CS
A1 = STORM_2D_Gen_Meas_Mat(width, height, div1, sigma);

% measurement matrix for ADCG
div2 = 2;                % upsampling factor in x y dimension
A2 = STORM_2D_Gen_Meas_Mat(width, height, div2, sigma);

%%
density_list = [0.1, 0.3, 0.6, 1:9];
iters = 1000;

im_list = cell(length(density_list), iters);
emitter_List = cell(length(density_list), iters);

FN_list = zeros(length(density_list), iters);
FP_list = zeros(length(density_list), iters);
t_list = zeros(length(density_list), iters);
DIFF_list = cell(length(density_list),1);

FN_list2 = zeros(length(density_list), iters);
FP_list2 = zeros(length(density_list), iters);
t_list2 = zeros(length(density_list), iters);
DIFF_list2 = cell(length(density_list),1);

for density_id = 1 : length(density_list)
    density = density_list(density_id);
    disp(['processing density ', num2str(density), '...']);
    for id = 1 : iters
        [im, emitterList] = STORM_2D_Simulation(density, pixelsize,...
            width, height, g_noise, photons, sigma);

        %% CSSTORM
        % start time
        t_start = tic;
        
        thresh = 150;
        finalList = STORM_2D_CS(A1, im, height, width, div1, thresh);
        
        % end time
        t1 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_2D_Precision_Cal(finalList, emitterList, minDist_xy);
        
        FN_list(density_id, id) = FN;
        FP_list(density_id, id) = FP;
        t_list(density_id, id) = t1;
        DIFF_list{density_id} = [DIFF_list{density_id}; DIFF];
        
        %% TVSTORM
        % start time
        t_start = tic;
        
        thresh = 150; % threshold for the reconstructed image
        ns = 0.9;
        [finalList2, I_list2] = TVSTORM_2D(A2, im, height, width, sigma, div2, ns, thresh);
        finalList2 = finalList2(I_list2 > 2 * thresh, :);
        
        % end time
        t2 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_2D_Precision_Cal(finalList2, emitterList, minDist_xy);
        
        FN_list2(density_id, id) = FN;
        FP_list2(density_id, id) = FP;
        t_list2(density_id, id) = t2;
        DIFF_list2{density_id} = [DIFF_list2{density_id}; DIFF];
        
        im_list{density_id, id} = im;
        emitter_List{density_id, id} = emitterList;
    end
end

%% Display
set(0,'DefaultAxesFontSize',12);

figure('Position', [100, 100, 430, 450]);
% Identified
FN_CSSTORM = mean(FN_list, 2);
FN_TVSTORM = mean(FN_list2, 2);

subplot(2,2,1); hold on;
plot(density_list,(1 - FN_CSSTORM)' .* density_list, 'bo-');
plot(density_list,(1 - FN_TVSTORM)'.* density_list, 'r^-');
plot([0, max(density_list)], [0, max(density_list)], 'k--');
box on;
legend('CSSTORM', 'TVSTORM');
axis equal;
axis([0, max(density_list), 0, max(density_list)]);
ylabel('Identified Density (emitters/\mum^2)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
ax.YTick = 0 : 9;
grid on;

% FP
FP_CSSTORM = mean(FP_list, 2);
FP_TVSTORM = mean(FP_list2, 2);

subplot(2, 2, 2); hold on;
plot(density_list, FP_CSSTORM, 'bo-');
plot(density_list, FP_TVSTORM, 'r^-');
xlim([0, max(density_list)]);
ylim([0 0.2]);
box on;
legend('CSSTORM', 'TVSTORM');
ylabel('False Discovery Rate');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% Precision
DIFF_CSSTORM = zeros(size(DIFF_list, 1), 2);
DIFF_TVSTORM = zeros(size(DIFF_list2, 1), 2);
for i = 1 : size(DIFF_list, 1)
    DIFF_CSSTORM(i, :) = std(DIFF_list{i});
end
for i = 1 : size(DIFF_list2, 1)
    DIFF_TVSTORM(i, :) = std(DIFF_list2{i});
end

subplot(2, 2, 3); hold on;
plot(density_list, sqrt(DIFF_CSSTORM(:, 1) .^ 2 + DIFF_CSSTORM(:, 2) .^ 2 ) * 75, 'bo-');
plot(density_list, sqrt(DIFF_TVSTORM(:, 1) .^ 2 + DIFF_TVSTORM(:, 2) .^ 2) * 75, 'r^-');
box on;
legend('CSSTORM', 'TVSTORM');
xlim([0, max(density_list)]);
ylabel('Precision (nm)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% time
t_CSSTORM = mean(t_list, 2);
t_TVSTORM = mean(t_list2, 2);
subplot(2, 2, 4);
semilogy(density_list, t_CSSTORM, 'bo-'); hold on;
semilogy(density_list, t_TVSTORM, 'r^-');
box on;
legend('CSSTORM', 'TVSTORM');
xlim([0, max(density_list)]);
ylabel('Execution Time (s)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;