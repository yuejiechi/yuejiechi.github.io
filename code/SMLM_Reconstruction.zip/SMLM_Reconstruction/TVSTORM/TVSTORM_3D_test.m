%% This is to test the TVSTORM algorithm with 3D STORM image reconstruction
close all;
clear;
clc;

%% Set up the parameters
density = 6;            % emitter density (fluorophores per um^2)
pixelsize = 0.075;      % camera pixel size (um)
width = 18;             % image width (pixel)
height = 18;            % image height (pixel)
g_noise = 0;            % gaussian noise level (photons/pixel)
photons = 500;          % average photon number
maxz = 0.4;             % maximum z position (um)

%% Generate measurement matrix
disp('Generating measurement matrix ...');
div1 = 8;                % upsampling factor in x y dimension
stacknum1 = 9;           % upsampling factor in z dimension
% 3D psf parameters measured in real system settings
data = load('three_d_parameter.mat');
curve_para = reshape(data.curve_para(:, 1, :), 5, 2);
% measurement matrix for CS
A1 = STORM_3D_Gen_Meas_Mat(maxz, stacknum1, width, height, div1, curve_para);

% measurement matrix for TVSTORM
div2 = 2;                % upsampling factor in x y dimension
stacknum2 = 5;           % upsampling factor in z dimension
A2 = STORM_3D_Gen_Meas_Mat(maxz, stacknum2, width, height, div2, curve_para);

%% Generate simulated image
disp('Generating simulated image ...');
[im, emitterList] = STORM_3D_Simulation(density, pixelsize,...
    width, height, g_noise, photons, maxz, curve_para);

%% Compressed sensing on the image
thresh = 50;
t1 = tic;
[clustCent1, xm1] = STORM_3D_CS(A1, im, height, width, div1,...
    stacknum1, maxz, thresh);
disp(['CS processing time: ', num2str(toc(t1)), ' seconds']);

%% TVSTORM
ns = 0.9;
thresh = 150;
t1 = tic;
[clustCent2, I_list2] = TVSTORM_3D(A2, im, height, width,...
    div2, stacknum2, maxz, ns, curve_para, thresh);
disp(['TVSTORM processing time: ', num2str(toc(t1)), ' seconds']);

%% Precision Calculation
minDist_xy = 1; % this is in pixel
minDist_z = 0.1; % this is in um
[FP1, FN1, DIFF1] = STORM_3D_Precision_Cal(clustCent1, emitterList,...
    minDist_xy, minDist_z);
[FP2, FN2, DIFF2] = STORM_3D_Precision_Cal(clustCent2, emitterList,...
    minDist_xy, minDist_z);
temp1 = std(DIFF1, [], 1);
temp2 = std(DIFF2, [], 1);
if ~isempty(temp1)
    disp('---------------CS---------------');
    disp(['FN: ', num2str(FN1, '%1.2f'), ', FP: ', num2str(FP1, '%1.2f'),...
        ', xy precision: ',...
        num2str(norm([temp1(1), temp1(2)]) * 75, '%5.2f'), ' nm',...
        ', z precision: ',...
        num2str(temp1(3) * 1000, '%5.2f'), ' nm']);
end
if ~isempty(temp2)
    disp('--------------TVSTORM--------------');
    disp(['FN: ', num2str(FN2, '%1.2f'), ', FP: ', num2str(FP2, '%1.2f'),...
        ', xy precision: ',...
        num2str(norm([temp2(1), temp2(2)]) * 75, '%5.2f'), ' nm',...
        ', z precision: ',...
        num2str(temp2(3) * 1000, '%5.2f'), ' nm']);
end

%% Display cs result
x2 = reshape(xm1, height * div1, width * div1, stacknum1);
x3 = sum(x2, 3);

clustCent_temp = clustCent1(:, 1 : 2) .* div1 - (div1 / 2 - 0.5);

figure;
subplot(1, 2, 1);
imagesc(im); axis equal; axis off; hold on; colormap gray;
plot(emitterList(:, 1), emitterList(:, 2),...
    'kx', 'MarkerSize', 7, 'LineWidth', 1.5);
title('Original image');

subplot(1, 2, 2);
imagesc(x3); axis equal; axis off; hold on; colormap gray;
title('Reconstructed emitter shape (CS)');

plot(emitterList(:, 1) * div1 - (div1 / 2 - 0.5),...
    emitterList(:, 2) * div1 - (div1 / 2 - 0.5),...
    'wx', 'MarkerSize', 8, 'LineWidth', 1.5);
hold on;
plot(clustCent_temp(:, 1), clustCent_temp(:, 2),...
    'ro', 'MarkerSize', 8, 'LineWidth', 1.5);

% plot the ellipsoid using the cs result
wx_list = STORM_3D_Model(curve_para(:, 1), clustCent1(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 2), clustCent1(:, 3));
for pt = 1 : size(wx_list, 1)
    h = plot_gaussian_ellipsoid(...
        [clustCent_temp(pt, 1), clustCent_temp(pt, 2)],...
        50 * div1 .* [wx_list(pt), 0; 0, wy_list(pt)]);
    set(h, 'color', 'r', 'Linewidth', 1);
end
% plot the ellipsoid using the original data
wx_list = STORM_3D_Model(curve_para(:, 1), emitterList(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 2), emitterList(:, 3));
for pt = 1 : size(emitterList, 1)
    h = plot_gaussian_ellipsoid(...
        emitterList(pt, 1 : 2) * div1 - (div1 / 2 - 0.5),...
        50 * div1 .* [wx_list(pt), 0; 0, wy_list(pt)]);
    set(h, 'color', 'w', 'Linewidth', 1);
end
set(gcf, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);

%% Display TVSTORM result
x2 = reshape(xm1, height * div1, width * div1, stacknum1);
x3 = sum(x2, 3);

clustCent_temp = clustCent2(:, 1 : 2) .* div1 - (div1 / 2 - 0.5);

figure;
subplot(1, 2, 1);
imagesc(im); axis equal; axis off; hold on; colormap gray;
plot(emitterList(:, 1), emitterList(:, 2),...
    'kx', 'MarkerSize', 7, 'LineWidth', 1.5);
title('Original image');

subplot(1, 2, 2);
imagesc(x3); axis equal; axis off; hold on; colormap gray;
title('Reconstructed emitter shape (TVSTORM)');

plot(emitterList(:, 1) * div1 - (div1 / 2 - 0.5),...
    emitterList(:, 2) * div1 - (div1 / 2 - 0.5),...
    'wx', 'MarkerSize', 8, 'LineWidth', 1.5);
hold on;
plot(clustCent_temp(:, 1), clustCent_temp(:, 2),...
    'ro', 'MarkerSize', 8, 'LineWidth', 1.5);

% plot the ellipsoid using the TVSTORM result
wx_list = STORM_3D_Model(curve_para(:, 1), clustCent2(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 2), clustCent2(:, 3));
for pt = 1 : size(wx_list, 1)
    h = plot_gaussian_ellipsoid(...
        [clustCent_temp(pt, 1), clustCent_temp(pt, 2)],...
        50 * div1 .* [wx_list(pt), 0; 0, wy_list(pt)]);
    set(h, 'color', 'r', 'Linewidth', 1);
end
% plot the ellipsoid using the original data
wx_list = STORM_3D_Model(curve_para(:, 1), emitterList(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 2), emitterList(:, 3));
for pt = 1 : size(emitterList, 1)
    h = plot_gaussian_ellipsoid(...
        emitterList(pt, 1 : 2) * div1 - (div1 / 2 - 0.5),...
        50 * div1 .* [wx_list(pt), 0; 0, wy_list(pt)]);
    set(h, 'color', 'w', 'Linewidth', 1);
end
set(gcf, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
