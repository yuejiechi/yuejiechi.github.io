%% This program analyzes sample_data.tif using MempSTORM

clear all;
close all;
clc;
warning off;

tif_name = 'sample_data.tif';

INFO = imfinfo(tif_name);
length = numel(INFO);

height = INFO.Height;
width = INFO.Width;

movie = zeros(height, width, length);

for i = 1 : length
    movie(:, :, i) = imread(tif_name, i, 'Info', INFO);
end

%% Generate data matrix
sigma = 1.7;

[XX, YY] = meshgrid(1 : width, 1 : height);
psf = 1000 / 4 *...
    (erf((XX - width / 2 + .5) / sqrt(2) / sigma) -...
    erf((XX - width / 2 - .5) / sqrt(2) / sigma)) .*...
    (erf((YY - height / 2 + .5) / sqrt(2) / sigma) -...
    erf((YY - height / 2 - .5) / sqrt(2) / sigma));

PSF = fft2(psf);

%% MempSTORM
finalList = [];
thresh = 3;

for i = 1 : length
    im = movie(:, :, i);
    IM = fft2(im);
    R = IM ./ PSF;
    X = fftshift(R);
    X = X(11 : 21, 11 : 21);
    k1idx = -5 : 5; k2idx = -5 : 5;
    k = 6; l = 6;

    [vec, ~] = MempSTORM(X, k, l, 'thresh', thresh, k1idx, k2idx);

    clustCent = [];
    if vec
        clustCent(:, 1) = mod(-width / 2 - mod(vec(:, 2), 1) * width, width);
        clustCent(:, 2) = mod(-height / 2 - mod(vec(:, 1), 1) * height, height);
        clustCent(:, 3) = vec(:, 3);
        clustCent(:, 4) = i;
    else
        clustCent = [];
    end
    
    finalList = [finalList; clustCent];
end

%% Drift correction
data = load('driftlist.mat');
finalList2(:, 1) = finalList(:, 1) + data.driftlist(finalList(:, 4), 1);
finalList2(:, 2) = finalList(:, 2) + data.driftlist(finalList(:, 4), 2);

%% save figures
% reconstruct the image
over_sampl_co = 10;

canvas = STORM_cloudPlot(finalList2(:, 1), finalList2(:, 2), ...
    [0 height 0 width], [], [height width] * over_sampl_co, finalList(:, 3));
close all;

myfilter = fspecial('gaussian', [10, 10], 1);
canvas2 = imfilter(canvas, myfilter, 'same');
imwrite(mat2gray(canvas2), 'reconstructed_MempSTORM.tif');