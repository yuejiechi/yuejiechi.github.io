%% This program analyzes sample_data.tif using MempSTORM

clear all;
close all;
clc;
warning off;

tif_name = 'sample_data.tif';

INFO = imfinfo(tif_name);
length = numel(INFO);

height = INFO.Height;
width = INFO.Width;

movie = zeros(height, width, length);

for i = 1 : length
    movie(:, :, i) = imread(tif_name, i, 'Info', INFO);
end

%% Generate measurement matrix
div = 2;
sigma = 1.7;
A = STORM_2D_Gen_Meas_Mat(width, height, div, sigma);

%% MempSTORM
finalList = [];

for i = 1 : length
    im = movie(:, :, i);
    
    ns = 0.9;
    thresh = 800;
    t1 = tic;
    [clustCent, I_list] = TVSTORM_2D(A, im, height, width, sigma, div, ns, thresh);

    if clustCent
        clustCent = [clustCent, I_list];
        clustCent(:, 4) = i;
    end
    
    finalList = [finalList; clustCent];
end

%% Drift correction
data = load('driftlist.mat');
finalList2(:, 1) = finalList(:, 1) + data.driftlist(finalList(:, 4), 1);
finalList2(:, 2) = finalList(:, 2) + data.driftlist(finalList(:, 4), 2);

%% save figures
% reconstruct the image
over_sampl_co = 10;

canvas = STORM_cloudPlot(finalList2(:, 1), finalList2(:, 2), ...
    [0 height 0 width], [], [height width] * over_sampl_co, finalList(:, 3));
close all;

myfilter = fspecial('gaussian', [10, 10], 1);
canvas2 = imfilter(canvas, myfilter, 'same');
imwrite(mat2gray(canvas2), 'reconstructed_TVSTORM.tif');