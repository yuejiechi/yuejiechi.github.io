function A = STORM_3D_Gen_Meas_Mat_Multi_Plane(maxz, stacknum, ...
    width, height, div, curve_para)
% PURPOSE:
% This function is to generate the measurement matrix for 3 camera
% 3D STORM image reconstruction.
%---------------------------------------------------
% USAGE:
% A = STORM_3D_Gen_Meas_Mat_Multi_Plane(maxz, stacknum, ...
%    width, height, div, curve_para)
%---------------------------------------------------
% INPUTS:
% maxz:         maximum distance between possible emitter and center in z
% stacknum:     number of layers of emitters
% width:        measured image width
% height:       measured image height
% div:          oversampling factor
% curve_para:   3D psf parameters
%---------------------------------------------------
% OUTPUTS:
% A:            generated measurement matrix
%---------------------------------------------------

zlist = linspace(-maxz, maxz, stacknum);
% meshgrid of original image size
[xx, yy] = meshgrid(1 : width, 1 : height);
% meshgrid of upsampled image size
[xxx, yyy, zzz] = meshgrid(0.5 + 1 / div / 2 : 1 / div : width + 0.5 - 1 / div / 2, ...
    0.5 + 1 / div / 2 : 1 / div : height + 0.5 - 1 / div / 2, zlist);
xx_r = xx(:); yy_r = yy(:);
xxx_r = xxx(:); yyy_r = yyy(:); zzz_r = zzz(:);

A = zeros(width * height * 3, size(xxx_r, 1));

% iterate through all upsampled grid points
for i = 1 : size(xxx_r, 1)
    for num = 1 : 3
        % get the width in x and y dimension
        wx = STORM_3D_Model(curve_para(:, num, 1), zzz_r(i));
        wy = STORM_3D_Model(curve_para(:, num, 2), zzz_r(i));
        % generate measurement on a given point
        A(((num - 1) * width * height + 1) : (num * width * height), i) = ...
            1 / 4 / 3 * (erf((xx_r + 0.5 - xxx_r(i)) / sqrt(2) / wx) - ...
            erf((xx_r - 0.5 - xxx_r(i)) / sqrt(2) / wx)) .* ...
            (erf((yy_r + 0.5 - yyy_r(i)) / sqrt(2) / wy) - ...
            erf((yy_r - 0.5 - yyy_r(i)) / sqrt(2) / wy));
    end
end