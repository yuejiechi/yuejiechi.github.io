function [clustCent, xm] = STORM_3D_CS(A, im, height, width, div,...
    stacknum, maxz, thresh, ns, di_wid, di_hei)
% PURPOSE:
% STORM 3D reconstruction using compressive sensing.
%---------------------------------------------------
% USAGE:
% [clustCent, xm] = STORM_3D_CS(A, im, height, width, div,...
%   stacknum, maxz, thresh, ns, di_wid, di_hei)
%---------------------------------------------------
% INPUTS:
% A:                measurement matrix
% im:               acquired image
% height:           image height
% width:            image width
% div:              upsampling factor in x y-dimension
% stacknum:         number of z-dimensional layers in
%                   generated measurement matrix
% maxz:             maximum z location of emitter (um)
% thresh:           threshold for reconstructed image
% ns:               parameter that controls the balance between
%                   data fidelity and sparsity
%                   typically 1.5 is used for Poisson noise
% di_wid:           dilation width in x y-dimension
% di_hei:           dilation height in z-dimension
%---------------------------------------------------
% OUTPUTS:
% clustCent(:, 1):  x coordinates (pixel)
% clustCent(:, 2):  y coordinates (pixel)
% clustCent(:, 3):  z coordinates (um)
% xm:               reconstructed upsampled image
%---------------------------------------------------
% REFERENCE:
% Huang, Jiaqing, Mingzhai Sun, Kristyn Gumpper, Yuejie Chi, and
% Jianjie Ma. "3D multifocus astigmatism and compressed sensing (3D MACS)
% based superresolution reconstruction."
% Biomedical optics express 6, no. 3 (2015): 902-917.
%---------------------------------------------------

%% Default values
if nargin <= 8
    ns = 1.5;
end
if nargin <= 9
    di_wid = 5;
end
if nargin <= 10
    di_hei = 3;
end

%% Pre-processing for compressed sensing
im = double(im(:));
eps = ns * sqrt(sum(im));
zlist = linspace(-maxz, maxz, stacknum);

%% Compressed sensing on the image
xm = STORM_Homotopy(A, im, 'tol', eps,...
    'isnonnegative', true, 'maxiteration', 500);

%% Post processing
xm = xm(1 : height * div * width * div * stacknum);
x2 = reshape(xm, height * div, width * div, stacknum);
% thresholding
BW = x2 > thresh;
se = ones([di_wid, di_wid, di_hei]);
% dilation
BW = imdilate(BW, se);
% debiasing
idx = find(BW(:) ~= 0);
A2 = A(:, idx);
xmm = xm;
xmm(idx) = lsqnonneg(A2, im);
% weighted centroid
x2 = reshape(xmm, height * div, width * div, stacknum);
STAT = regionprops(BW == 1, x2, 'WeightedCentroid', 'PixelValues');

clustCent = cat(1, STAT.WeightedCentroid);
for statid = 1 : size(STAT, 1)
    clustCent(statid, 4) = sum(STAT(statid).PixelValues);
end

if ~isempty(clustCent)
    clustCent(isnan(clustCent(:, 1)), :) = []; % remove nan
    clustCent(:, 1) = (clustCent(:, 1) + (div / 2 - 0.5)) / div;
    clustCent(:, 2) = (clustCent(:, 2) + (div / 2 - 0.5)) / div;
    clustCent(:, 3) = interp1(1 : stacknum, zlist, clustCent(:, 3), 'pchip');
end