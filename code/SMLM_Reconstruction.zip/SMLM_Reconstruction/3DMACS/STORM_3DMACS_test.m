%% This is to test the 3D MACS and 3D SACS algorithm with STORM images
clear all;
close all;
clc;

%% set up the parameters
density = 8; % unit: fluorophores per um^2
pixelsize = 0.075;
width = 18;
height = 18;
g_noise = 0;
photons = 500;
div = 8; % zoom factor

maxz = 0.4; % maximum z position (um)
stacknum = 9;

maxplanedist = 0.2; % maximum plane position (um)
planenum = 3; % set the plane number
planelist = linspace(-maxplanedist, maxplanedist, planenum);
zlist = linspace(-maxz, maxz, stacknum);

%% calculate the measurement matrix
load('calibration.mat');
A = STORM_3D_Gen_Meas_Mat_Multi_Plane(maxz, stacknum, width, height, div, curve_para);
A2 = A(1 : end / 3, : ) * 3;

%% generate the simulated images
[im, emitterList, im2] = STORM_3D_Simulation_Multi_Plane(density, pixelsize, ...
        width, height, g_noise, photons, maxz, curve_para);
im_1Cam = imnoise(uint16(im2(:, :, 1)) * 3, 'poisson');

%% 3D MACS on the image
[clustCent, xm] = STORM_3D_CS(A, im, height, width, div, stacknum, maxz, photons / 2);

%% 3D SACS on the image
[clustCent2, xm2] = STORM_3D_CS(A2, im_1Cam, height, width, div, stacknum, maxz, photons / 2);

%% display 3Cam
im2 = reshape(im, height, width, planenum);
x2 = reshape(xm, height * div, width * div, stacknum);
x3 = sum(x2, 3);
im_construct = A * xm;
im_construct = reshape(im_construct, height, width, planenum);

clustCent_original = clustCent(:, 1 : 2) .* div - (div / 2 - 0.5);

figure;
for num = 1 : planenum
    subplot(planenum, 3, (num - 1) * 3 + 1);
    imagesc(im2(:, :, num)); axis equal; axis off; hold on; colormap gray;
    plot(emitterList(:, 1), emitterList(:, 2), 'kx', 'MarkerSize', 7, 'LineWidth', 1.5);

    subplot(planenum, 3, (num - 1) * 3 + 2);
    imagesc(im_construct(:, :, num)); axis equal; axis off; colormap gray;

    subplot(planenum, 3, (num - 1) * 3 + 3);
    imagesc(x3); axis equal; axis off; hold on; colormap gray;

    plot(emitterList(:, 1) * div - (div / 2 - 0.5), ...
        emitterList(:, 2) * div - (div / 2 - 0.5), ...
        'wx', 'MarkerSize', 8, 'LineWidth', 1.5);
    hold on;
    plot(clustCent_original(:, 1), clustCent_original(:, 2), ...
        'ro', 'MarkerSize', 8, 'LineWidth', 1.5);

    % plot the ellipsoid using the cvx result
    wx_list = STORM_3D_Model(curve_para(:, num, 1), clustCent(:, 3));
    wy_list = STORM_3D_Model(curve_para(:, num, 2), clustCent(:, 3));
    for pt = 1 : size(wx_list, 1)
        h = plot_gaussian_ellipsoid([clustCent_original(pt, 1), ...
            clustCent_original(pt, 2)], ...
            50 * div .* [wx_list(pt) 0; 0 wy_list(pt)]);
        set(h, 'color', 'r', 'Linewidth', 1);
    end
    % plot the ellipsoid using the original data
    wx_list = STORM_3D_Model(curve_para(:, num, 1), emitterList(:, 3));
    wy_list = STORM_3D_Model(curve_para(:, num, 2), emitterList(:, 3));
    for pt = 1 : size(emitterList, 1)
        h = plot_gaussian_ellipsoid(...
            emitterList(pt, 1 : 2) * div - (div / 2 - 0.5), ...
            50 * div .* [wx_list(pt) 0; 0 wy_list(pt)]);
        set(h, 'color', 'w', 'Linewidth', 1);
    end
end
set(gcf, 'units', 'normalized', 'outerposition', [0 0 1 1]);

%% display 1Cam
x2 = reshape(xm2, height * div, width * div, stacknum);
x3 = sum(x2, 3);
im_construct = A2 * xm2;
im_construct = reshape(im_construct, height, width);

clustCent_original = clustCent2(:, 1 : 2) .* div - (div / 2 - 0.5);

figure;
subplot(1, 3, 1);
imagesc(im_1Cam); axis equal; axis off; hold on; colormap gray;
plot(emitterList(:, 1), emitterList(:, 2), 'kx', 'MarkerSize', 7, 'LineWidth', 1.5);

subplot(1, 3, 2);
imagesc(im_construct); axis equal; axis off; colormap gray;

subplot(1, 3, 3);
imagesc(x3); axis equal; axis off; hold on; colormap gray;

plot(emitterList(:, 1) * div - (div / 2 - 0.5), ...
    emitterList(:, 2) * div - (div / 2 - 0.5), ...
    'wx', 'MarkerSize', 8, 'LineWidth', 1.5);
hold on;
plot(clustCent_original(:, 1), clustCent_original(:, 2), ...
    'ro', 'MarkerSize', 8, 'LineWidth', 1.5);

% plot the ellipsoid using the cvx result
wx_list = STORM_3D_Model(curve_para(:, 1, 1), clustCent2(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 1, 2), clustCent2(:, 3));
for pt = 1 : size(wx_list, 1)
    h = plot_gaussian_ellipsoid([clustCent_original(pt, 1), ...
        clustCent_original(pt, 2)], ...
        50 * div .* [wx_list(pt) 0; 0 wy_list(pt)]);
    set(h, 'color', 'r', 'Linewidth', 1);
end
% plot the ellipsoid using the original data
wx_list = STORM_3D_Model(curve_para(:, 1, 1), emitterList(:, 3));
wy_list = STORM_3D_Model(curve_para(:, 1, 2), emitterList(:, 3));
for pt = 1 : size(emitterList, 1)
    h = plot_gaussian_ellipsoid(...
        emitterList(pt, 1 : 2) * div - (div / 2 - 0.5), ...
        50 * div .* [wx_list(pt) 0; 0 wy_list(pt)]);
    set(h, 'color', 'w', 'Linewidth', 1);
end
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
