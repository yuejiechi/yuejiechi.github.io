function [im, emitterList, im_noisefree] = STORM_3D_Simulation_Multi_Plane(density, pixelsize, ...
    width, height, g_noise, photons, maxz, curve_para)
% PURPOSE:
% Generate simulated 3D STORM images for 3 planes.
%---------------------------------------------------
% USAGE:
% [movie, emitterList, im_noisefree] = STORM_3D_Multi_Plane_Simulation(density, pixelsize, ...
%    width, height, g_noise, photons, maxz, maxplanedist, planenum)
%---------------------------------------------------
% INPUTS:
% density:      fluorophores density (molecules/um^2)
% pixelsize:    pixel size (um)
% width:        image width
% height:       image height
% g_noise:      gaussian noise level (photons/pixel)
% photons:      total photons emitted by a single fluorophore in one frame
% maxz:         maximum z position (in um)
%---------------------------------------------------
% OUTPUTS:
% im:           simulated image (noised)
% emitterList:  list consisting emitter coordinates
% im_noisefree: simulated image without noise
%---------------------------------------------------

myseed=RandStream.create('mrg32k3a', 'NumStreams', 2^10, 'seed', 'shuffle');
RandStream.setGlobalStream(myseed);

xx = linspace(1, width, width)';
yy = linspace(1, height, height)';
[XX, YY] = meshgrid(xx, yy);

%% Generate the emitterlist
margin = 3;
% average active fluorophores per frame
P = density * (width - 2 * margin - 1) ^ 2 * pixelsize ^ 2; % average on molecules per frame
% round P to integer randomly
if rand() < (P - floor(P))
    P = round(P) + 1;
else
    P = round(P);
end

% generate emitters location randomly
emitterList = rand(P, 3);
emitterList(:, 1) = emitterList(:, 1) * (width - 2 * margin - 1) + margin + 1;
emitterList(:, 2) = emitterList(:, 2) * (height - 2 * margin - 1) + margin + 1;
emitterList(:, 3) = emitterList(:, 3) * maxz - maxz / 2;

%% Generate the image
I = zeros(height, width, 3);
% iterate through all emitters
for j = 1 : size(emitterList, 1)
    r0_vec = emitterList(j , 1 : 3);
    for num = 1 : 3
        % get the width in x and y dimension
        wx = STORM_3D_Model(curve_para(:, num, 1), r0_vec(3));
        wy = STORM_3D_Model(curve_para(:, num, 2), r0_vec(3));
        % generate measurement for the corresponding camera on a given
        % point
        I(:, :, num) = I(:, :, num) + photons / 4 *...
            (erf((XX + 0.5 - r0_vec(1)) / sqrt(2) / wx) -...
            erf((XX - 0.5 - r0_vec(1)) / sqrt(2) / wx)) .*...
            (erf((YY + 0.5 - r0_vec(2)) / sqrt(2) / wy) -...
            erf((YY - 0.5 - r0_vec(2)) / sqrt(2) / wy));
    end
end
% Poisson noise
I_noise = uint16(I);
I_noise = imnoise(I_noise, 'poisson');
% Gaussian noise
I_noise = double(I_noise) + g_noise .* randn(width, height, 3);
I_noise = uint16(I_noise);
im = double(I_noise);
im_noisefree = double(I);