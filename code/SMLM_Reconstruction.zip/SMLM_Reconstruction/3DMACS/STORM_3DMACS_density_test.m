%% This is to test the performance of 3D MACS vs. 3D SACS on simulated
%  data under different densities
clear all;
close all;
warning off;
clc;

width = 20;
height = 20;

pixelsize = 0.075;
g_noise = 0;
photons = 1500;
div = 8; % zoom factor

maxz = 0.4; % maximum z position (um)
stacknum = 11;

%% calculate the measurement matrix
data = load('calibration.mat');
curve_para2 = data.curve_para2;
curve_para = data.curve_para;
A = STORM_3D_Gen_Meas_Mat_Multi_Plane(maxz, stacknum, width, height, ...
    div, curve_para);
A2 = A(1 : end / 3, :) * 3;

%%
density_list = [0.6, 1 : 9];
iters = 1000;

im_list = cell(length(density_list), iters);
emitter_List = cell(length(density_list), iters);

FN_list = zeros(length(density_list), iters);
FP_list = zeros(length(density_list), iters);
t_list = zeros(length(density_list), iters);
DIFF_list = cell(length(density_list),1);

FN_list2 = zeros(length(density_list), iters);
FP_list2 = zeros(length(density_list), iters);
t_list2 = zeros(length(density_list), iters);
DIFF_list2 = cell(length(density_list),1);

minDist_xy = 1; % this is in pixel
minDist_z = 0.1; % this is in um

for density_id = 1 : length(density_list)
    density = density_list(density_id);
    disp(['processing density ', num2str(density), '...']);
    for id = 1 : iters
        [im, emitterList, im2] = STORM_3D_Simulation_Multi_Plane(density, ...
            pixelsize, width, height, g_noise, photons, maxz, curve_para);
        im_1Cam = imnoise(uint16(im2(:, :, 1)) * 3, 'poisson');

        %% 3D MACS
        % start time
        t_start = tic;
        
        thresh = photons / 2; % threshold for the reconstructed image
        finalList = STORM_3D_CS(A, im, height, width, div, stacknum, maxz, thresh);
        
        % end time
        t1 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_3D_Precision_Cal(finalList, emitterList, minDist_xy, minDist_z);
        
        FN_list(density_id, id) = FN;
        FP_list(density_id, id) = FP;
        t_list(density_id, id) = t1;
        DIFF_list{density_id} = [DIFF_list{density_id}; DIFF];
        %% 3D SACS
        % start time
        t_start = tic;
        
        thresh = photons / 2; % threshold for the reconstructed image
        finalList2 = STORM_3D_CS(A2, im_1Cam, height, width, div, stacknum, maxz, thresh);
        
        % end time
        t2 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_3D_Precision_Cal(finalList2, emitterList, minDist_xy, minDist_z);
        
        FN_list2(density_id, id) = FN;
        FP_list2(density_id, id) = FP;
        t_list2(density_id, id) = t2;
        DIFF_list2{density_id} = [DIFF_list2{density_id}; DIFF];
        
        im_list{density_id, id} = im;
        emitter_List{density_id, id} = emitterList;
    end
end

%% Display
set(0,'DefaultAxesFontSize',12);

figure('Position', [100, 100, 430, 450]);
% Identified
FN_3DMACS = mean(FN_list, 2);
FN_3DSACS = mean(FN_list2, 2);

subplot(2,2,1); hold on;
plot(density_list,(1 - FN_3DMACS)' .* density_list, 'bo-');
plot(density_list,(1 - FN_3DSACS)' .* density_list, 'r^-');
plot([0, max(density_list)], [0, max(density_list)], 'k--');
box on;
legend('3D MACS', '3D SACS');
axis equal;
axis([0, max(density_list), 0, max(density_list)]);
ylabel('Identified Density (emitters/\mum^2)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
ax.YTick = 0 : 9;
grid on;

% FP
FP_3DMACS = mean(FP_list, 2);
FP_3DSACS = mean(FP_list2, 2);

subplot(2, 2, 2); hold on;
plot(density_list, FP_3DMACS, 'bo-');
plot(density_list, FP_3DSACS, 'r^-');
xlim([0, max(density_list)]);
ylim([0 0.2]);
box on;
legend('3D MACS', '3D SACS');
ylabel('False Discovery Rate');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% Precision
DIFF_3DMACS = zeros(size(DIFF_list, 1), 3);
DIFF_3DSACS = zeros(size(DIFF_list2, 1), 3);
for i = 1 : size(DIFF_list, 1)
    DIFF_3DMACS(i, :) = std(DIFF_list{i});
end
for i = 1 : size(DIFF_list2, 1)
    DIFF_3DSACS(i, :) = std(DIFF_list2{i});
end

subplot(2, 2, 3); hold on;
plot(density_list,sqrt((DIFF_3DMACS(:, 1) * 75) .^ 2 + ...
    (DIFF_3DMACS(:, 2) * 75) .^ 2 * 75 + (DIFF_3DMACS(:, 3) * 1000) .^ 2), ...
    'bo-');
plot(density_list,sqrt((DIFF_3DSACS(:, 1) * 75) .^ 2 + ...
    (DIFF_3DSACS(:, 2) * 75) .^ 2 * 75 + (DIFF_3DSACS(:, 3) * 1000) .^ 2), ...
    'r^-');box on;
legend('3D MACS', '3D SACS');
xlim([0, max(density_list)]);
ylabel('Precision (nm)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% time
t_3DMACS = mean(t_list, 2);
t_3DSACS = mean(t_list2, 2);
subplot(2, 2, 4);
semilogy(density_list, t_3DMACS, 'bo-'); hold on;
semilogy(density_list, t_3DSACS, 'r^-');
box on;
legend('3D MACS', '3D SACS');
xlim([0, max(density_list)]);
ylabel('Execution Time (s)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;