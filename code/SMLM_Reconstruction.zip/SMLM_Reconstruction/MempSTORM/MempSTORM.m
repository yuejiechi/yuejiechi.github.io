function [vec, line] = STORM_MempSTORM(X, k, l, option, val, k1idx, k2idx)
% PURPOSE:
% Perform MempSTORM algorithm on data matrix X.
%---------------------------------------------------
% USAGE:
% [vec, line] = STORM_MempSTORM(X, k, l, 'thresh', thresh, k1idx, k2idx)
% or
% [vec, line] = STORM_MempSTORM(X, k, l, 'nspikes', I, k1idx, k2idx)
%---------------------------------------------------
% INPUTS:
% X = 2D data matrix
% k = number of blocks in Hankel block matrix
% l = number of row in each Hankel matrix
% option = option for threshold to get nspikes or nspikes directly
% thresh = threshold for selecting number of spikes
% k1idx (optional) = index of k1
% k2idx (optional) = index of k2
%---------------------------------------------------
% OUTPUTS:
% vec = two dimensional result output by STORM_MEMP
% line = detected frequencies (before pairing)
%---------------------------------------------------
% REFERENCE:
% Huang, J., Gumpper, K., Chi, Y., Sun, M., & Ma, J. (2015).
% Fast two-dimensional super-resolution image reconstruction
% algorithm for ultra-high emitter density.
% Optics Letters, 40(13), 2989-2992.
%---------------------------------------------------

% Copyright (C)
% Jiaqing Huang
% Mingzhai Sun
% The Ohio State University
% mingzhai@gmail.com
% 08-Feb-2015

%% Matrix Enhancement
M = size(X, 1); N = size(X, 2);
Xe = zeros(k * l, (M - k + 1) * (N - l + 1));

hankel_list = zeros(l, N - l + 1, M);
for id = 1 : M
    hankel_list(:, :, id) = hankel(X(id, 1 : l), X(id, l : end));
end

for yid = 0 : k - 1
    for xid = 0 : M - k
        id = xid + yid + 1;
        Xe(yid * l + 1 : (yid + 1) * l,...
            xid * (N - l + 1) + 1 : (xid + 1) * (N - l + 1))...
            = hankel_list(:, :, id);
    end
end

%% Matrix Pencil
[U, S, ~] = svd(Xe);

switch lower(option)
    case 'thresh'
        I = sum(diag(S) > val);
    case 'nspikes'
        I = val;
    otherwise
        error('unknown option');
end

% shuffle matrix
P = zeros(k * l, k * l);
for yid = 1 : k * l
    P(yid, (floor((yid - 1) / k) + 1) + mod(yid - 1, k) * l) = 1;
end

% preparation for pole extraction
Us = U(:, 1 : I);
U1 = Us(1 : end - l, :);
U2 = Us(l + 1 : end, :);

Usp = P * Us;
U1p = Usp(1 : end - l, :);
U2p = Usp(l + 1 : end, :);

% pole extraction
yy = eigs(pinv(U1) * U2, I);
zz = eigs(pinv(U1p) * U2p, I);

rec_t1spikes = mod(angle(yy) / 2 / pi, 1);
rec_t2spikes = mod(angle(zz) / 2 / pi, 1);

%% Pairing
rect1 = kron(rec_t1spikes(:)', ones(1,I));
rect2 = kron(ones(1, I), rec_t2spikes(:)');
if nargin == 7
    k1 = kron(ones(1, N), k1idx);
    k2 = kron(k2idx, ones(1, M));
else
    k1 = kron(ones(1, N), 0 : M-1);
    k2 = kron(0 : N - 1, ones(1, M));
end
Frec = exp(1i * 2 * pi * (k1' * rect1 + k2' * rect2)); % Fourier matrix 

a = lsqnonneg([real(Frec); imag(Frec)], [real(X(:)); imag(X(:))]);

[~, ind] = sort(abs(a), 'descend');

if strcmp(option, 'thresh')
    I = min(I, sum(a(ind) > val / 2));
end

if I == 0
    vec = [];
else
    vec(:, 1) = rect1(ind(1 : I));
    vec(:, 2) = rect2(ind(1 : I));
    vec(:, 3) = a(ind(1 : I));
end
line = [rec_t1spikes(:), rec_t2spikes(:)];