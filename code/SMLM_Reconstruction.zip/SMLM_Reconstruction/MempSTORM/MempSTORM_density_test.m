%% This is to test the performance of MempSTORM vs. CSSTORM on simulated
%  data under different densities
clear all;
close all;
warning off;
clc;

width = 30;
height = 30;

pixelsize = 0.075;
g_noise = 0;
photons = 1500;
sigma = 1.5;

%% generate data matrix
[XX,YY] = meshgrid(1 : width, 1 : height);
psf = photons / 4 *...
    (erf((XX - width / 2 + .5) / sqrt(2) / sigma) - ...
    erf((XX - width / 2 - .5) / sqrt(2) / sigma)) .* ...
    (erf((YY - height / 2 + .5) / sqrt(2) / sigma) - ...
    erf((YY - height / 2 - .5) / sqrt(2) / sigma));

PSF = fft2(psf);

%% generate measurement matrix
div = 8;
A = STORM_2D_Gen_Meas_Mat(width, height, div, sigma);

%%
density_list = [0.6, 1 : 9];
iters = 1000;

im_list = cell(length(density_list), iters);
emitter_List = cell(length(density_list), iters);

FN_list = zeros(length(density_list), iters);
FP_list = zeros(length(density_list), iters);
t_list = zeros(length(density_list), iters);
DIFF_list = cell(length(density_list),1);

FN_list2 = zeros(length(density_list), iters);
FP_list2 = zeros(length(density_list), iters);
t_list2 = zeros(length(density_list), iters);
DIFF_list2 = cell(length(density_list),1);

for density_id = 1 : length(density_list)
    density = density_list(density_id);
    disp(['processing density ', num2str(density), '...']);
    for id = 1 : iters
        [im, emitterList] = STORM_2D_Simulation(density, pixelsize, ...
            width, height, g_noise, photons, sigma);

        %% MEMP
        % start time
        t_start = tic;
        
        IM = fft2(im);
        R = IM ./ PSF;
        X = fftshift(R);
        X = X(11 : 21, 11 : 21);
        k1idx = -5 : 5; k2idx = -5 : 5;
        k = 6; l = 6;
        thresh = 0.9;

        [vec, line] = MempSTORM(X, k, l, 'thresh', thresh, k1idx, k2idx);
        
        finalList = [];
        if vec
            finalList(:, 1) = mod(-width / 2 - mod(vec(:, 2), 1) * width, width);
            finalList(:, 2) = mod(-height / 2 - mod(vec(:, 1), 1) * height, height);
        else
            finalList = [];
        end
        
        % end time
        t1 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_2D_Precision_Cal(finalList, emitterList, minDist_xy);
        
        FN_list(density_id, id) = FN;
        FP_list(density_id, id) = FP;
        t_list(density_id, id) = t1;
        DIFF_list{density_id} = [DIFF_list{density_id}; DIFF];
        %% 2D CS
        % start time
        thresh = 50;
        ns = 1.5;
        di_wid = 3;
        t_start = tic;
        clustCent = STORM_2D_CS(A, im, height, width, div, thresh, ns, di_wid);
        
        % end time
        t2 = toc(t_start);
        
        % calculate performance
        minDist_xy = 1;
        [FP, FN, DIFF] = STORM_2D_Precision_Cal(clustCent, emitterList, minDist_xy);
        
        FN_list2(density_id, id) = FN;
        FP_list2(density_id, id) = FP;
        t_list2(density_id, id) = t2;
        DIFF_list2{density_id} = [DIFF_list2{density_id}; DIFF];
        
        im_list{density_id, id} = im;
        emitter_List{density_id, id} = emitterList;
    end
end

%% Display
set(0,'DefaultAxesFontSize',12);

figure('Position', [100, 100, 430, 450]);
% Identified
FN_MEMP = mean(FN_list, 2);
FN_CS = mean(FN_list2, 2);

subplot(2,2,1); hold on;
plot(density_list,(1 - FN_MEMP)' .* density_list, 'bo-');
plot(density_list,(1 - FN_CS)' .* density_list, 'r^-');
plot([0, max(density_list)], [0, max(density_list)], 'k--');
box on;
legend('MempSTORM', 'CSSTORM');
axis equal;
axis([0, max(density_list), 0, max(density_list)]);
ylabel('Identified Density (emitters/\mum^2)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
ax.YTick = 0 : 9;
grid on;

% FP
FP_MEMP = mean(FP_list, 2);
FP_CS = mean(FP_list2, 2);

subplot(2, 2, 2); hold on;
plot(density_list, FP_MEMP, 'bo-');
plot(density_list, FP_CS, 'r^-');
xlim([0, max(density_list)]);
ylim([0 0.2]);
box on;
legend('MempSTORM', 'CSSTORM');
ylabel('False Discovery Rate');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% Precision
DIFF_MEMP = zeros(size(DIFF_list, 1), 2);
DIFF_CS = zeros(size(DIFF_list2, 1), 2);
for i = 1 : size(DIFF_list, 1)
    DIFF_MEMP(i, :) = std(DIFF_list{i});
end
for i = 1 : size(DIFF_list2, 1)
    DIFF_CS(i, :) = std(DIFF_list2{i});
end

subplot(2, 2, 3); hold on;
plot(density_list, sqrt(DIFF_MEMP(:, 1) .^ 2 + DIFF_MEMP(:, 2) .^2 ) * 75, 'bo-');
plot(density_list, sqrt(DIFF_CS(:, 1) .^ 2 + DIFF_CS(:, 2) .^ 2) * 75, 'r^-');
box on;
legend('MempSTORM', 'CSSTORM');
xlim([0, max(density_list)]);
ylabel('Precision (nm)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;

% time
t_MEMP = mean(t_list, 2);
t_CS = mean(t_list2, 2);
subplot(2, 2, 4);
semilogy(density_list, t_MEMP, 'bo-'); hold on;
semilogy(density_list, t_CS, 'r^-');
box on;
legend('MempSTORM', 'CSSTORM');
xlim([0, max(density_list)]);
ylabel('Execution Time (s)');
xlabel('Density (emitters/\mum^2)');
ax = gca;
ax.XTick = 0 : 9;
grid on;