%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script is to test the MempSTORM algorithm described in paper
% Huang, J., Gumpper, K., Chi, Y., Sun, M., & Ma, J. (2015).
% Fast two-dimensional super-resolution image reconstruction
% algorithm for ultra-high emitter density.
% Optics Letters, 40(13), 2989-2992.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Generate image
clear all;
close all
clc;

% set up paramters
width = 30;
height = 30;
sigma = 2;
photons = 1500;
density = 2;
pixelsize = 0.075;
g_noise = 0;

[im, emitterList] = STORM_2D_Simulation(density, pixelsize, ...
    width, height, g_noise, photons, sigma);
I = size(emitterList, 1);

%% Generate data matrix
[XX, YY] = meshgrid(1 : width, 1 : height);
psf = photons / 4 *...
    (erf((XX - width / 2 + .5) / sqrt(2) / sigma) -...
    erf((XX - width / 2 - .5) / sqrt(2) / sigma)) .*...
    (erf((YY - height / 2 + .5) / sqrt(2) / sigma) -...
    erf((YY - height / 2 - .5) / sqrt(2) / sigma));

PSF = fft2(psf);
IM = fft2(im);
R = IM ./ PSF;

%% MEMP
X = fftshift(R);
X = X(11 : 21, 11 : 21);
k1idx = -5 : 5; k2idx = -5 : 5;
k = 6; l = 6;
tic;
[vec, line] = MempSTORM(X, k, l, 'nspikes', I, k1idx, k2idx);
toc;
finalList(:, 1) = mod(-width / 2 - mod(vec(:, 2), 1) * width, width);
finalList(:, 2) = mod(-height / 2 - mod(vec(:, 1), 1) * height, height);

line(:, 1) = mod(-height / 2 - mod(line(:, 1), 1) * height, height);
line(:, 2) = mod(-width / 2 - mod(line(:, 2), 1) * width, width);
line = line(:, [2, 1]);

%% Display
figure; hold on;
imagesc(im);
colormap gray;
axis equal;
axis off;

for i = 1 : size(line, 1)
    plot([line(i, 1), line(i, 1)], [1, height], 'y--');
    plot([1, width], [line(i, 2), line(i, 2)], 'y--');
end

plot(emitterList(:, 1), emitterList(:, 2), 'ro');
plot(finalList(:, 1), finalList(:, 2), 'bx');