Single Molecule Localization Microscopy (SMLM) reconstruction algorithms for the following papers:

1. Huang, Jiaqing, Mingzhai Sun, Kristyn Gumpper, Yuejie Chi, and Jianjie Ma. "3D multifocus astigmatism and compressed sensing (3D MACS) based superresolution reconstruction." Biomedical optics express 6, no. 3 (2015): 902-917.

2. Huang, Jiaqing, Kristyn Gumpper, Yuejie Chi, Mingzhai Sun, and Jianjie Ma. "Fast two-dimensional super-resolution image reconstruction algorithm for ultra-high emitter density." Optics letters 40, no. 13 (2015): 2989-2992.

3. Huang, Jiaqing, Mingzhai Sun, and Yuejie Chi. "Super-resolution image reconstruction for high-density 3D single-molecule microscopy." In Biomedical Imaging (ISBI), 2016 IEEE 13th International Symposium on. 2016.

—--------------------- Content —---------------------
1. 3DMACS
- STORM_3DMACS_test.m: test program for 3D MACS algorithm.
- STORM_3DMACS_density_test.m: performance evaluation of 3D MACS vs. 3D SACS.
- calibration.mat: calibration information for multi-camera system PSF.

2. MempSTORM
- MempSTORM_test.m: test program for MempSTORM algorithm.
- MempSTORM_density_test.m: performance evaluation of MempSTORM vs. CSSTORM.

3. TVSTORM
- TVSTORM_2D_test.m: test program for 2D TVSTORM algorithm.
- TVSTORM_2D_density_test.m: performance evaluation of TVSTORM vs. CSSTORM in 2D image reconstruction.
- TVSTORM_3D_test.m: test program for 3D TVSTORM algorithm.
- TVSTORM_3D_density_test.m: performance evaluation of TVSTORM vs. CSSTORM in 3D image reconstruction.
- three_d_parameter.mat: calibration information for system PSF.

4. Util
Utility programs.

5. Data
sample_data.tif: 20000 frames of image cropped from data collected in real SMLM setup.
driftlist.mat: image shift for each frame.
sample_data_analyze_MempSTORM.m: image analysis of sample_data.tif using MempSTORM.
sample_data_analyze_TVSTORM.m: image analysis of sample_data.tif using TVSTORM.

—--------------------- Note —---------------------
Here CSSTORM uses the de-biasing technique in 3D MACS paper.

—--------------------- Contact —---------------------
Jiaqing Huang
jqhuang1990@gmail.com

Mingzhai Sun
mingzhai@ustc.edu.cn

Yuejie Chi
chi.97@osu.edu