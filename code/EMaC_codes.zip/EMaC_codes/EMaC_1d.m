% EMaC algorithm for estimating 1-D spectrally-sparse objects
% See full paper:
% Robust Spectral Compressed Sensing via Structured Matrix Completion
% http://arxiv.org/pdf/1304.8126.pdf
% Yuejie Chi, Yuxin Chen

clear all
%rand('state',271) % random seed fixed so that the example is the one in the paper

% Problem data 

nspikes = 4;

Nc = 95; % signal dimension

k = 0:Nc-1; T = 30;

t1spikes = rand(1,nspikes); 


%amplitudes 
dynamic_range=10;
x = exp(-1i*2*pi*rand(nspikes,1)).*(1 + 10.^(rand(nspikes,1).*(dynamic_range/20))); % amplitudes can also be complex
%% data 
N =(Nc+1)/2;
temp = randperm(Nc);
k1 = temp(1:T)-1;


F = exp(1i*2*pi*(k1'*t1spikes)); % Fourier matrix on observed entries
yfull = exp(1i*2*pi*(k'*t1spikes))*x;



y_clean = F*x; % clean data
y = y_clean; % observed data without noise


%% Solve SDP

% build a hankel matrix

tic

cvx_solver sdpt3
cvx_begin sdp quiet
    variable Y(N,N) hermitian
    variable Z(N,N) hermitian
    variable u(Nc,1) complex 
    minimize 0.5*trace(Y)+0.5*trace(Z)
    subject to
        [Y, hankel(u(1:N),u(N:end)); 
         hankel(u(1:N),u(N:end))', Z] >=0
        u(k1+1) == y;
    
cvx_end

toc


%% estimate the frequencies using esprit
res_err = norm(u-yfull)/norm(yfull)
figure;
stem(abs(yfull),'bo-'); hold on;
stem(abs(u),'rx-');

