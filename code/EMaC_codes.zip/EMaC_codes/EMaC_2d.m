% EMaC algorithm for estimating 2-D spectrally-sparse objects
% See full paper:
% Robust Spectral Compressed Sensing via Structured Matrix Completion
% http://arxiv.org/pdf/1304.8126.pdf
% Yuejie Chi, Yuxin Chen

clear all
%rand('state',271) % random seed fixed so that the example is the one in the paper

% Problem data 

% cutoff frequency


Nc = 11; % signal dimension
T = 50; % number of observed entries
nspikes = 4;

% nominal spacing
tnominal =  0:nspikes-1;
% spike locations
t1spikes =  rand(1,nspikes);

t2spikes =  rand(1,nspikes);
% amplitudes 
dynamic_range= 0;
x = exp(-1i*2*pi*rand(nspikes,1)) .* (1 + 10.^(rand(nspikes,1).*(dynamic_range/20))); % amplitudes can also be complex
%% data 
  
k = 0:Nc-1; 
% random observation pattern
k1 = randi(Nc,1,T)-1; 
k2 = randi(Nc,1,T)-1;

yfull = exp(1i*2*pi*(kron(k',ones(Nc,1))*t1spikes+kron(ones(Nc,1),k')*t2spikes))*x/Nc;

F = exp(1i*2*pi*(k1'*t1spikes+k2'*t2spikes))/Nc; % Fourier matrix 


% observed data
y = F*x ; n = Nc;

%% Solve SDP


% build a hankel matrix
N =(Nc+1)/2;

% I will build a square hankel matrix for simplicity


cvx_solver sdpt3
cvx_begin sdp quiet
    variable Y(N^2,N^2) hermitian
    variable Z(N^2,N^2) hermitian
    variable u(Nc,Nc) complex 
    variable M(N^2,N^2) complex
    minimize (0.5*trace(Y)+0.5*trace(Z))
    
    for m1 = 1:N
        for m2 = 1:m1
            M((m1-m2)*N+1:(m1-m2+1)*N,(m2-1)*N+1:m2*N) == hankel(u(m1,1:N),u(m1,N:end));
        end
    end
    for m1 = N+1:Nc
        for m2 = m1-N+1:N
            M((m1-m2)*N+1:(m1-m2+1)*N,(m2-1)*N+1:m2*N) == hankel(u(m1,1:N),u(m1,N:end));
        end
    end
     
    subject to
        [Y, M; 
         M', Z] >=0
        norm(u(k1'*Nc+k2'+1) - y)<=1e-8; % tolerance
    
cvx_end


% reconstruction error
res_err = norm(reshape(u,Nc^2,1)-yfull)/norm(yfull)

figure;
stem(abs(yfull),'bo-'); hold on;
stem(abs(reshape(u,Nc^2,1)),'rx-');

