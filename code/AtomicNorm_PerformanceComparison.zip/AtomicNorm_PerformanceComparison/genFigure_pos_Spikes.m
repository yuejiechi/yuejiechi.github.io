% Generate experimental data for Fig7

close all
clear all

load('fig7.mat');


%% Compute CRB

CRB = zeros(numAlpha, numSNR);
for i = 1:numAlpha
    [V0,V1] = vdm_pos([-alphaList(i)/(2*n),alphaList(i)/(2*n)],n);
    u0 = V1(:,1);
    u1 = V1(:,2);
    x = V0*[1;1];
    xpow = norm(x)^2/n;
    for j = 1:numSNR
        SNR = SNRList(j);
        sigma = sqrt(xpow*db2pow(-SNR));
        CRB(i,j) = sigma^2*(norm(u0)^2 - abs(u0'*u1)^2/norm(u1)^2)^(-1);
    end
end

%% MSE vs SNR

figure;

subplot(3,1,3);

semilogy(SNRList, MSE_anm(1,:), '-o',SNRList,MSE_posanm(1,:), '-s', SNRList,MSE_cadzow(1,:),'-d',SNRList,MSE_music(1,:),'-*',SNRList, CRB(1,:),'--k','LineWidth',1.5,'MarkerSize',8);
xlabel('SNR (dB)');
ylabel('Mean squared error');
legend('ANM','Positive ANM','Prony''s with Cadzow','Root-MUSIC','CRB','Location','southwest','FontSize',12);
title('\alpha = 0.5');
l1 = legend('ANM','Positive ANM','Prony''s with Cadzow','Root-MUSIC','CRB','Location','southwest','FontSize',12);
set(l1,'NumColumns',2,'Location','southwest','FontSize',12);
set(gca(),'FontName','times new roman','FontSize',12);

subplot(3,1,2);
semilogy(SNRList, MSE_anm(2,:), '-o',SNRList,MSE_posanm(2,:), '-s', SNRList,MSE_cadzow(2,:),'-d',SNRList,MSE_music(1,:),'-*',SNRList, CRB(1,:),'--k','LineWidth',1.5,'MarkerSize',8);
xlabel('SNR (dB)');
ylabel('Mean squared error');
l2 = legend('ANM','Positive ANM','Prony''s with Cadzow','Root-MUSIC','CRB','Location','southwest','FontSize',12);
set(l2,'NumColumns',2,'Location','southwest','FontSize',12);
title('\alpha = 0.75');
set(gca(),'FontName','times new roman','FontSize',12);

subplot(3,1,1);
semilogy(SNRList, MSE_anm(3,:), '-o',SNRList,MSE_posanm(3,:), '-s', SNRList,MSE_cadzow(3,:),'-d',SNRList,MSE_music(3,:),'-*',SNRList, CRB(3,:),'--k','LineWidth',1.5,'MarkerSize',8);
xlabel('SNR (dB)');
ylabel('Mean squared error');
l3 = legend('ANM','Positive ANM','Prony''s with Cadzow','Root-MUSIC','CRB','Location','southwest','FontSize',12);
set(l3,'NumColumns',2,'Location','southwest','FontSize',12);
title('\alpha = 1');
set(gca(),'FontName','times new roman','FontSize',12);

