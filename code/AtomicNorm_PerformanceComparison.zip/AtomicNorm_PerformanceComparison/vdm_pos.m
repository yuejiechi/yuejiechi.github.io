function [V0,V1,V2] = vdm_pos(T,n)

s = length(T);
T = reshape(T,1,s);

V0 = exp(1i*2*pi*((0:(n-1)).')*T);

if nargout > 1
    V1 = 1i*2*pi*((0:(n-1)).').* V0;
end

if nargout > 2
    V2 = -4*pi^2 *(((0:(n-1)).^2).') .* V0;
end

end