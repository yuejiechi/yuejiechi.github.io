Authors: Yuejie Chi and Maxime Ferreira Da Costa
Email: {yuejiechi;mferreira}@cmu.edu

This folder includes the Matlab code for the numerical experiments presented in "Harnessing Sparsity Over the Continuum: Atomic norm minimization for superresolution, Y Chi, M Ferreira Da Costa - IEEE Signal Processing Magazine, 2020"

The Matlab scripts of this packages require an installation of CVX (http://cvxr.com) to run.
Usage of the Mosek solver (https://www.mosek.com/) is recommended.

There are 4 main Matlab scripts:

1. performanceComparison_neg.m (Fig.6)
Generate experiments for two spikes with opposite amplitudes +1 and -1, and save them in the file fig6.mat

2. performanceComparison_pos.m (Fig.7)
Generate experiments for two spikes with identical amplitudes +1 and +1, and save them in the file fig7.mat

3. genFigure_neg_Spikes
Compute the CRB and display Fig.6

4. genFigure_pos_Spikes
Compute the CRB and display Fig.7

