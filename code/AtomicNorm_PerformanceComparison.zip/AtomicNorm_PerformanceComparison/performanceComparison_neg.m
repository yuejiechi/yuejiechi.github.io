% Generate experimental data for Fig6

clear all
close all
clc

[~, hostname] = system('hostname');
savepath = 'fig6.mat';

n = 101;

alphaList = [1.5,1.75,2];
numAlpha = length(alphaList);

SNRList = -10:2:30;
numSNR = length(SNRList);

numTrials = 200;

% T_posanm = cell(numAlpha,numSNR,numTrials);
% q_posanm = cell(numAlpha,numSNR,numTrials);

T_anm = cell(numAlpha,numSNR,numTrials);
q_anm = cell(numAlpha,numSNR,numTrials);

T_music = cell(numAlpha,numSNR,numTrials);

T_cadzow = cell(numAlpha,numSNR,numTrials);

zList = cell(numAlpha,numSNR,numTrials);

backup_posanm = logical(zeros(numAlpha,numSNR,numTrials));
backup_anm = logical(zeros(numAlpha,numSNR,numTrials));

c = 1.2;
c_backup = 0.8;

for i = 1:numAlpha
    alpha = alphaList(i);
    Ttrue = [-alpha/(2*n);alpha/(2*n)];
    V = vdm_pos(Ttrue,n);
    x = V*[-1;1];
    
    xpow = norm(x)^2/n;
    for l=1:numSNR
        disp(['Loop ',num2str([i,l])])
        SNR = SNRList(l);
        sigma = sqrt(db2pow(-SNR)*xpow);
        lambda = c*sigma*sqrt(n*log(n));
        
        parfor j = 1:numTrials
            z = x + (sigma/sqrt(2))*(randn(n,1) + 1i*randn(n,1));
            zList{i,l,j} = z;

            %ANM
            [q] = DualAST(z,lambda);
            T_ANM = estimateFrequenciesFromDualPolynomial_shrink(q,1e-4,z,2);
            
            if length(T_ANM) ~= 2
                backup_anm(i,l,j) = true;
                
                [q] = DualAST(z,c_backup*sigma*sqrt(n*log(n)));
                T_ANM = estimateFrequenciesFromDualPolynomial_shrink(q,1e-4,z,2);
            end
            q_anm{i,l,j} = q;
            T_anm{i,l,j} = T_ANM;
            
            %Root MUSIC
            T_music{i,l,j} = sort(rootmusic(z,2)/(2*pi));
            
            %Prony's method with Cadzow denoising
            zDenoised = cadzowDenoising(z,100);
            T_cadzow{i,l,j} = cadzowEstimator(zDenoised);
        end
        
        save(savepath);
    end
end

%% Dual-POSITIVE_ANM analysis

MSE_anm = zeros(numAlpha,numSNR);
MSE_anmOnSuccess = zeros(numAlpha,numSNR);

%ANM
for i = 1:numAlpha
    alpha = alphaList(i);
    for l = 1:numSNR
        squareErrorCurrent = 0;
        squareErroCurrentOnSuccess = 0;
        numSuccess = 0;
        for j = 1:numTrials
            Tcurrent = T_anm{i,l,j};
            if length(Tcurrent) == 2
                squareErrorCurrent = squareErrorCurrent + min((Tcurrent(1) + alpha/(2*n))^2 + (Tcurrent(2) - alpha/(2*n))^2, (Tcurrent(2) + alpha/(2*n))^2 + (Tcurrent(1) - alpha/(2*n))^2);
                squareErroCurrentOnSuccess = squareErroCurrentOnSuccess + min((Tcurrent(1) + alpha/(2*n))^2 + (Tcurrent(2) - alpha/(2*n))^2, (Tcurrent(2) + alpha/(2*n))^2 + (Tcurrent(1) - alpha/(2*n))^2);
                numSuccess = numSuccess + 1;
            else
                warning('ANM: 0 or 1 spike estimated');
                squareErrorCurrent = squareErrorCurrent + 1/4;
            end
        end
        MSE_anm(i,l) = squareErrorCurrent/(2*numTrials);
        MSE_anmOnSuccess(i,l) = squareErroCurrentOnSuccess/(2*numSuccess);
    end
end

%Root-MUSIC
MSE_music = zeros(numAlpha,numSNR);

for i = 1:numAlpha
    alpha = alphaList(i);
    for l = 1:numSNR
        squareErrorCurrent = 0;
        for j = 1:numTrials
            Tcurrent = T_music{i,l,j};
            squareErrorCurrent = squareErrorCurrent + min((Tcurrent(1) + alpha/(2*n))^2 + (Tcurrent(2) - alpha/(2*n))^2, (Tcurrent(2) + alpha/(2*n))^2 + (Tcurrent(1) - alpha/(2*n))^2);
        end
        MSE_music(i,l) = squareErrorCurrent/(2*numTrials);
    end
end

%Prony's with Cadzow
MSE_cadzow = zeros(numAlpha,numSNR);

for i = 1:numAlpha
    alpha = alphaList(i);
    for l = 1:numSNR
        squareErrorCurrent = 0;
        for j = 1:numTrials
            Tcurrent = T_cadzow{i,l,j};
            squareErrorCurrent = squareErrorCurrent + min((Tcurrent(1) + alpha/(2*n))^2 + (Tcurrent(2) - alpha/(2*n))^2, (Tcurrent(2) + alpha/(2*n))^2 + (Tcurrent(1) - alpha/(2*n))^2);
        end
        MSE_cadzow(i,l) = squareErrorCurrent/(2*numTrials);
    end
end

%% Save

save(savepath);
