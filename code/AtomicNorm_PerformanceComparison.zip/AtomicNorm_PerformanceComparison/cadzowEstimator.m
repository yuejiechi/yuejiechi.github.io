function [Tcadzow] = cadzowEstimator(z)
%Cadzow estimator to estimate two frequency components of an input signal z

n = length(z);
A = [z(3:end),z(2:(end-1)),z(1:(end-2))];

[U,S,V] = svd(A,'econ');

h = V(:,3);
Tcadzow = sort(angle(roots(h))/(2*pi));
end