function [q] = DualAST(y,lambda)
%Solve the dual SDP associated to the ANM estimator for an input
%signal z and a regularization parameter lambda.


n = length(y);

yc = y/lambda;

cvx_begin sdp quiet

variable X(n+1,n+1) complex semidefinite;

X(n+1,n+1) == 1;

trace(X(1:n,1:n)) == 1;
for j = 1:(n-1)
    sum(diag(X(1:n,1:n),j)) == 0; 
end


minimize((yc - X(1:n,n+1))'*(yc - X(1:n,n+1)));
cvx_end

q = X(1:n,n+1);

end
