function T = estimateFrequenciesFromDualPolynomial_real_shrink(qReal, eps, z, k)
%Estimate the frequencies in a signal z of a signal given the real part
%qReal of the solution q of the DualAST_positive program. It is possible to specify the model order k

N = length(qReal);
n = floor((N+1)/2);

r = qReal;
r(n) = r(n) - 1;

r_roots = roots(r);
r_roots_detected = r_roots(abs(1-abs(r_roots)) < eps);

T_est = angle(r_roots_detected)/(2*pi);
T_est = sort(T_est);

T_est = T_est(1:2:end); %Remove multiplicity 2

if length(T_est) < k
    %warning('Underestimating number of frequencies');
    T = T_est;
    return;
end

c = lscov(vdm_pos(T_est,n), z);
[~,idx] = sort(abs(c),'descend');

T = sort(T_est(idx(1:k)));
end

