function [q,qReal] = DualAST_positive(z,lambda)
%Solve the dual SDP associated to the positive ANM estimator for an input
%signal z and a regularization parameter lambda.

n = length(z);

cvx_begin sdp quiet

variable H(n,n) complex semidefinite; % H(w) is of degree m so that |H(w)|^2 is of degree n-1
variable q(n,1) complex;              % Q(w) is a dual certificate of degree n-1

trace(H) + real(q(1)) == 1;
for j = 1:(n-1)
     sum(diag(H,j)) + q(j+1)/2 == 0; % 1 - real(Q(w)) = |H(w)|^2
end

maximize( real(z'*q) - lambda/2*(q'*q)); %LASSO penalty
cvx_end

qReal = [conj(flipud(q(2:end)))/2; real(q(1)) ;q(2:end)/2]; %Coefficients of the real part of Q(w)

end