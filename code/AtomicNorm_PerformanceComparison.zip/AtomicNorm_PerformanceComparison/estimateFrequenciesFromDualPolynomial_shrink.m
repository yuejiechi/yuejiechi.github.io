function T = estimateFrequenciesFromDualPolynomial_shrink(q, epsRoot, z, k)
%Estimate the frequencies in a signal z of a signal given the dual solution
%q of the DualAST program. It is possible to specify the model order k

n = length(q);

qSquare = conv(conj(q), flipud(q)); %Modulus square of the polynom

r = qSquare;
r(n) = r(n) - 1;

r_roots = roots(r);
r_roots_detected = r_roots(abs(1-abs(r_roots)) < epsRoot);

T_est = angle(r_roots_detected)/(2*pi);
T_est = sort(T_est);

T_est = T_est(1:2:end); %Remove multiplicity 2

if length(T_est) < k
    %warning('Underestimating number of frequencies');
    T = T_est;
    return;
end

c = lscov(vdm_pos(T_est,n), z);
[~,idx] = sort(abs(c),'descend');

T = sort(T_est(idx(1:k)));
end

