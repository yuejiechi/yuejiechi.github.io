function zCadzow = cadzowDenoising(z,gap)
%Cadzow denoising for an input signal z and gap value 'gap'

n = length(z);
A = [z(3:end),z(2:(end-1)),z(1:(end-2))];

[U,S,V] = svd(A,'econ');

maxIter = 1;

%Denoising
while ((maxIter <= 500)) % && (S(2,2) < gap*S(3,3)))
Anext = U*diag([S(1,1),S(2,2),0])*V';
zNext = zeros(n,1);

for k = 1:n
    zNext(k) = mean(diag(Anext,3-k));
end

A = [zNext(3:end),zNext(2:(end-1)),zNext(1:(end-2))];
[U,S,V] = svd(A,'econ');
maxIter = maxIter + 1;

end

zCadzow = zeros(n,1);
for k = 1:n
    zCadzow(k) = mean(diag(A,3-k));
end

end