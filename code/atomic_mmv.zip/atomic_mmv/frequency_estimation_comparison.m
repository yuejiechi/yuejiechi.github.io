%%
%% Frequency estimation comparison
%% Structured covariance estimation / Atomic norm minimization / Correlation awareness / Cs frame
%% Generate the first row of fig. 8 in paper http://arxiv.org/abs/1408.2242 (version 2)
%%

clear all;
clc;


n = 64; % length of each measurement
m = 8; % number of partial observations
k = 6; % sparsity level
L = 400; % number of measurement vectors


%amplitudes
amps = (1/sqrt(2))*(randn(k,L)+1i*randn(k,L)); %complex normal distribution CN(0,1)
sigma = sqrt(n) * (0.3*rand(1,k)+0.9);
amps_up = diag(sigma) * amps;

%frequencies
poles = [0.0052, 0.0120, 0.3185, 0.4303, 0.4360, 0.7210];
        
%signal
t = (0:1:n-1).';
basis = (exp(2*pi*1i*t*poles))/sqrt(n);
signal = basis * amps_up;
        
%subsampling signal
temp = randperm(n);
subsample_index = sort(temp(1:m));
observed = signal(subsample_index,:); %same observation subset
%indices of subsampling covariance
sub_index = zeros(n,n);
for index_1 = 1:1:m
    for index_2 = 1:1:m
        sub_index(subsample_index(index_1),subsample_index(index_2)) = 1;
    end
end
 
%sample covariance matrix
Rs = (1/L) * (signal * signal');

%true covaricane matrix
coefs = (sigma.^2).';
actual_r = basis * coefs / sqrt(n);
actual_R = toeplitz(actual_r).';

%normalized estimation error
err  = @(x) norm((actual_R - x), 'fro')/norm(actual_R, 'fro'); %error metric -- covariance
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%structured covariance estimation
T0 = clock;
tau = 0.005 / ((log(L))^2) / ((log(m)));
cvx_solver sdpt3
cvx_begin sdp quiet
    variable u_TH(n,n) hermitian toeplitz
    minimize (square_pos(norm((sub_index.*(u_TH - Rs)), 'fro')) + tau * trace(u_TH))
    subject to
        u_TH >= 0;
cvx_end     
   
%music
[W_TH,POW_TH] = rootmusic(u_TH,k,'corr');
fs_TH = mod(W_TH/2/pi,1);
    
fprintf('structured covariance estimation   MSE = %.6f  TiME = %.2f s\n\n',  err(u_TH), etime(clock,T0));
              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%traditional CS in 4-frame
T0 = clock;
grid_CSF = n * 4;
fs_CSF = (0:1:(grid_CSF-1))/grid_CSF;
t_CSF = (0:1:n-1).';
basis_CSF = (exp(2*pi*1i*t_CSF*fs_CSF))/sqrt(n);
cvx_solver sdpt3
cvx_begin sdp quiet
    variable theta_CSF(grid_CSF, L) complex
    variable temp_CSF(n, L) complex
    minimize (sum(norms(theta_CSF, 2, 2)))
    temp_CSF == basis_CSF * theta_CSF;
    subject to
       temp_CSF(subsample_index,:) == observed;
cvx_end
x_CSF = basis_CSF * theta_CSF;
the_CSF = (norms(theta_CSF, 2, 2).^2)/L;
Rs_CSF = (1/L) * (x_CSF * x_CSF');
   
fprintf('CS 4-frame   MSE = %.6f  TiME = %.2f s\n\n',  err(Rs_CSF), etime(clock,T0));
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%atomic norm minimization
T0 = clock;
cvx_solver sdpt3
cvx_begin sdp quiet
    variable x_AT(n, L) complex
    variable w_AT(L, L) complex hermitian 
    variable u_AT(n,n) hermitian toeplitz
    minimize (trace(u_AT) + trace(w_AT))
    subject to
        [u_AT,x_AT;x_AT',w_AT] >= 0;
         x_AT(subsample_index,:) == observed;
cvx_end
%music
R_AT = (1/L) * (x_AT * x_AT');
[W_AT,POW_AT] = rootmusic(R_AT,k,'corr');
fs_AT = mod(W_AT/2/pi,1);

   
fprintf('atomic norm minimization   MSE = %.6f  TiME = %.2f s\n\n',  err(R_AT), etime(clock,T0));

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%correlation awareness
%Rs partial
T0 = clock;
Rs_partial = (1/L) * (observed * observed');
Rs_partial_vec = vec(Rs_partial);
            
grid_KR = n * 4;
fs_KR = (0:1:(grid_KR-1))/grid_KR;
t_KR = (0:1:n-1).';
basis_KR = (exp(2*pi*1i*t_KR*fs_KR))/sqrt(n);
basis_KR_partial = basis_KR(subsample_index,:);

basis_new = kr(conj(basis_KR_partial), basis_KR_partial);

   
h = 0.0002 / ((log(L))^2) / ((log(m))^2);
cvx_solver sdpt3
cvx_begin sdp quiet
    variable r_KR(grid_KR,1)
    minimize (0.5*square_pos(norm(basis_new*r_KR - Rs_partial_vec)) + h * sum(r_KR))
    subject to
         r_KR >= 0;
cvx_end


basis_KR_total = kr(conj(basis_KR), basis_KR);
Rs_KR_estimated_vec = basis_KR_total * r_KR;
Rs_KR_estimated = reshape(Rs_KR_estimated_vec, n, n);

fprintf('correlation awareness   MSE = %.6f  TiME = %.2f s\n\n',  err(Rs_KR_estimated), etime(clock,T0));
    
 
    
  
%plot figure
xx = real(exp(2*pi*1i*(0:0.001:1)));
yy = imag(exp(2*pi*1i*(0:0.001:1)));
zz = zeros(1,length(0:0.001:1));
    
figure(1)
%plot ground truth
plot3(xx,yy,zz,'-k','LineWidth',0.002);
grid on;
hold on;
xx_o = real(exp(2*pi*1i*poles));
yy_o = imag(exp(2*pi*1i*poles));
zz_o = (sigma.^2)/n;
stem3(xx_o,yy_o,zz_o,'xr');
xlim([-1,1]);
ylim([-1,1]);
zlim([0,2]);
title('Ground truth');
    
figure(2)
%plot structured covariance estimation
plot3(xx,yy,zz,'-k','LineWidth',0.002);
grid on;
hold on;
xx_covariance = real(exp(2*pi*1i*fs_TH));
yy_covariance = imag(exp(2*pi*1i*fs_TH));
zz_covariance = POW_TH;
stem3(xx_covariance,yy_covariance,zz_covariance,'xr');
xlim([-1,1]);
ylim([-1,1]);
zlim([0,2]);
title('structured covariance estimation');
    
figure(3)
%plot cs frame
plot3(xx,yy,zz,'-k','LineWidth',0.002);
grid on;
hold on;
xx_CSF = real(exp(2*pi*1i*fs_CSF));
yy_CSF = imag(exp(2*pi*1i*fs_CSF));
zz_CSF = the_CSF / n;
stem3(xx_CSF,yy_CSF,zz_CSF,'xr');
xlim([-1,1]);
ylim([-1,1]);
zlim([0,2]);
title('CS with DFT frame');
        
figure(4)
%plot Atomic norm minimization
plot3(xx,yy,zz,'-k','LineWidth',0.002);
grid on;
hold on;
xx_atomic = real(exp(2*pi*1i*fs_AT));
yy_atomic = imag(exp(2*pi*1i*fs_AT));
zz_atomic = POW_AT;
stem3(xx_atomic,yy_atomic,zz_atomic,'xr');
xlim([-1,1]);
ylim([-1,1]);
zlim([0,2]);
title('Atomic norm minimization');
    
figure(5)
%plot correlation-aware with DFT frame
plot3(xx,yy,zz,'-k','LineWidth',0.002);
grid on;
hold on;
xx_KR = real(exp(2*pi*1i*fs_KR));
yy_KR = imag(exp(2*pi*1i*fs_KR));
zz_KR = r_KR / n;
stem3(xx_KR,yy_KR,zz_KR,'xr');
xlim([-1,1]);
ylim([-1,1]);
zlim([0,2]);
title('Correlation-aware with DFT frame');
    
