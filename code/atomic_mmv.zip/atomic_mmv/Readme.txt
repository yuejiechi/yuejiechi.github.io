This is the code to regenerate some of the figures in the paper: http://arxiv.org/abs/1408.2242 (Version 2)

Please send your questions to the authors if there’re any.

1. structured_covariance_estimation

Structured covariance matrix estimation from partial observations of finite 
measurement vectors. Generate fig. 5.

2. frequency_estimation_comparison (kr)

Comparison of frequency estimation obtained from structured covariance estimation,
atomic norm minimization, CS with frame and correlation awareness algorithm respectively.
Generate the first row of fig. 8. 'kr.m' is a function used by correlation awareness algorithm.

3. signal_denoising (atomic_admm)

Signal denoising with full observations using atomic norm minimization, which is implemented using ADMM. Comparison of numerical results and the 
theoretical bound. Generate fig. 3.