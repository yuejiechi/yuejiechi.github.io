%%
%% Structured covariance matrix estimation from partial observations of finite measurement vectors
%% Generate fig. 5 in paper http://arxiv.org/abs/1408.2242 (version 2)
%%

clear all;
clc;


n = 64; % length of each measurement vector
m = 15; % number of partial observations
k_vector = 1:2:13; % sparsity level
L_vector = [20, 100, 500, 1000, 5000]; % number of measurement vectors

trialtime = 50;

NMSE = zeros(length(L_vector), length(k_vector));


for L_index = 1:1:length(L_vector)
    
    for k_index = 1:1:length(k_vector)
        
        for trial = 1:1:trialtime
            %parameters
            L = L_vector(L_index);
            k = k_vector(k_index);
            
            %amplitudes
            amps = (1/sqrt(2))*(randn(k,L)+1i*randn(k,L)); 
            sigma = ones(1,k);
            amps_up = diag(sigma) * amps;
            %frequencies
            poles = sort(rand(1,k)); 
            t = (0:1:n-1).';
            basis = (exp(2*pi*1i*t*poles))/sqrt(n);
            %signal
            signal = basis * amps_up;
            
            %sample covariance matrix
            Rs = (1/L) * signal * signal';
            %true covaricane matrix
            coefs = (sigma.^2).';
            actual_r = basis * coefs / sqrt(n);
            actual_R = toeplitz(actual_r).';

            %normalized estimation error
            err  = @(x) norm((actual_r - x), 2)/norm(actual_r, 2); 
            
     
            %%random chosen partial observations
            %subsampling signal
            temp_rand = randperm(n);
            subsample_index_rand = sort(temp_rand(1:m));
            observed_rand = signal(subsample_index_rand,:);
            %indices of subsampling covariance
            sub_index_rand = zeros(n,n);
            for index_1 = 1:1:m
                for index_2 = 1:1:m
                    sub_index_rand(subsample_index_rand(index_1),subsample_index_rand(index_2)) = 1;
                end
            end
            
            %estimate the covariance
            tau = 0.005 / ((log(L))^2) / (log(m));
            cvx_solver sdpt3
            cvx_begin sdp quiet
                variable u_rand(n,n) hermitian toeplitz
                minimize (square_pos(norm((sub_index_rand.*(u_rand - Rs)), 'fro')) + tau * trace(u_rand))
                subject to
                    u_rand >= 0;
            cvx_end
            %%
            NMSE(L_index, k_index) = NMSE(L_index, k_index) + err(u_rand(:,1))/trialtime;
            %%
            fprintf('structured covariance estimation  L = %d  k = %d  trial = %d  MSE = %.6f\n\n', L, k, trial, err(u_rand(:,1)));
                        
        end
    end
end


%figure
figure
plot(k_vector, NMSE(1,:),'-s');
hold on;
plot(k_vector, NMSE(2,:),'-+g');
hold on;
plot(k_vector, NMSE(3,:),'-xr');
hold on;
plot(k_vector, NMSE(4,:),'-dc');
hold on;
plot(k_vector, NMSE(5,:),'-*m');
xlabel('sparsity level r');
ylabel('normalized estimation error $||\hat{\bf{u}}-\bf{u}^{\star}||_{2}/||\bf{u}^{\star}||_{2}$','Interpreter','latex');
legend('L=20','L=100','L=500','L=1000','L=5000');
ylim([0, 0.5]);
xlim([1, 13]);
grid on;