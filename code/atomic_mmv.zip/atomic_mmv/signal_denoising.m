%%
%% Signal denoising via atomic norm minimization with full measurements
%% Comparison of numerical results and the theoretical bound
%% Generate fig. 3 in paper http://arxiv.org/abs/1408.2242 (version 2)
%%

clear all;
clc;


n = 64; % length of each measurement
k = 8; % sparsity level
L_vector = [1:1:10, 15:5:100]; % number of measurement vectors

total_trial = 50;
matrix_NMSE = zeros(1,length(L_vector));
per_vector_NMSE = zeros(1,length(L_vector));
x_true_atomic = zeros(1,length(L_vector));
tau_vector = zeros(1,length(L_vector));


%frequencies
poles = [0.056, 0.142, 0.354, 0.399, 0.521, 0.673, 0.740, 0.901];
t = (0:1:n-1).';
basis = (exp(2*pi*1i*t*poles))/sqrt(n);

%nose
sigma2 = (0.1)^2;
amps_initial = (1/sqrt(2))*(randn(k,L_vector(length(L_vector)))+1i*randn(k,L_vector(length(L_vector))));


for L_index = 1:1:length(L_vector)
   
    L = L_vector(L_index);
    amps = amps_initial(:,1:L); %complex normal distribution CN(0,1)
    %signal
    signal = basis * amps;
    
    %atomic norm of ground truth
    C = norms(amps, 2, 2);
    x_true_atomic(1,L_index) = sum(C);
    tau_vector(1,L_index) = (sigma2/2)^(0.5) * (1+1/(log(n)))^(0.5) * (2*L+2*(log(8*pi*n*L*log(n)))+2*(sqrt(2*L*log(8*pi*n*L*log(n))))+sqrt(2*pi)*sqrt(L)+2)^(0.5);
    fprintf('atomic norm minimization  L = %d     x_true_atomic = %.6f       tau_vector = %.6f \n\n', L, x_true_atomic(1,L_index), tau_vector(1,L_index));
 
    for trial = 1:1:total_trial       
       
        %noise
        noise = sqrt(sigma2) * (1/sqrt(2)) * (randn(n,L)+1i*randn(n,L));

        observed = signal + noise;
        %error metric
        err  = @(x) ((norm((signal - x), 'fro'))^2); 
        %tau
        tau = tau_vector(1,L_index);
        %atomic norm minimization implemented by admm
        T0 = clock;
        [x_AT,dual_poly_coeffs,Tu] = atomic_admm(observed,tau);

        matrix_NMSE(1,L_index) = matrix_NMSE(1,L_index) + err(x_AT)/total_trial;
        fprintf('atomic norm minimization  L = %d    trial = %d    matrix_MSE = %.6f  per_vector__MSE = %.6f  TiME = %.2f s\n\n', L, trial, err(x_AT), err(x_AT)/L,  etime(clock,T0));

    end
    
    per_vector_NMSE(1,L_index) = matrix_NMSE(1,L_index)/L;
end


%figure
figure(1)
plot(L_vector, per_vector_NMSE,'r*-');
hold on;
plot(L_vector, 2*tau_vector.*x_true_atomic./L_vector, '-bo');
xlabel('the number of measurement vectors L');
ylabel('MSE $||\hat{\bf{X}}-\bf{X}^{\star}||^{2}_{F}/L$','Interpreter','latex');
legend('Numerical results', 'Theoretical bounds');
grid on;
