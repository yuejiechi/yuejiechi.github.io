function [X,dual_poly_coeffs,Tu] = atomic_admm(Z,tau)

%size of mesurements
Z_size = size(Z);
n = Z_size(1,1);
L = Z_size(1,2);

%parameters
maxIter = 5000; % maximum number of ADMM steps
rho = 2.0; % penalty parameter in augmented Lagrangian
tol_abs = 1e-4; %absolute tolerance 1e-3
tol_rel = 1e-5; % iteration level relative tolerance 1e-4
converged = 0;

%initialization
YOld = zeros(n+L);
Lambda = zeros(n+L);
normalizer = 1./[n; ((n-1):-1:1)'];
e1 = zeros(n,1); e1(1)=1;


for count = 1:1:maxIter  
    
    %update the variables W,X, and u
    W = YOld(n+1:n+L,n+1:n+L)...
        + (1/rho)*(Lambda(n+1:n+L,n+1:n+L) - (tau/2)*eye(L));
    X = (1/(2*rho+1))*(Z... 
        + 2*Lambda(n+1:n+L,1:n)'... 
        + rho*YOld(1:n,n+1:n+L) ...
        + rho*YOld(n+1:n+L,1:n)');
    u = (1/rho) * normalizer.*conj(toeplitz_adjoint(Lambda(1:n,1:n))... 
        + rho*toeplitz_adjoint(YOld(1:n,1:n)) - (tau/2)*n*e1);
   
    %temp is the matrix that should be psd.
    temp = [toeplitz(conj(u)), X; X', W];
    
    
    %projection of Q onto the semidefinite cone
    Q = temp - Lambda/rho;
    [V,E] = eig(Q);   
    e = diag(E);
    idx = (e>0);
    Y = V(:,idx)*diag(e(idx))*V(:,idx)';
    Y = (Y+Y')/2;   
    
    %stop criteria.
    pri_res = temp - Y;

    dual_res_norm = rho*sqrt((norm(Y(1:n,n+1:n+L)-YOld(1:n,n+1:n+L),'fro'))^2/L+(norm(toeplitz_adjoint(Y(1:n,1:n)-YOld(1:n,1:n)),'fro'))^2+(norm(Y(n+1:n+L,n+1:n+L)-YOld(n+1:n+L,n+1:n+L),'fro'))^2/L);
    dual_var_adj_norm = rho*sqrt((norm((Lambda(1:n,n+1:n+L)+Lambda(n+1:n+L,1:n)')/2,'fro'))^2/L+(norm(toeplitz_adjoint(Lambda(1:n,1:n)),'fro'))^2+(norm(Lambda(n+1:n+L,n+1:n+L),'fro'))^2/L);
    
    pri_tol = (n+L)*tol_abs + tol_rel*max(norm(temp,'fro'),norm(Y,'fro'));
    dual_tol = sqrt(2*n+1)*tol_abs + tol_rel*dual_var_adj_norm;
    
    err_rec_primal = norm(pri_res,'fro');
    err_rec_dual = dual_res_norm;
    
    converged = and(err_rec_primal<pri_tol,err_rec_dual<dual_tol);
    if converged, break; end
   
    Lambda = Lambda + rho*(Y - temp);
    YOld = Y;    
end

if count == maxIter
    fprintf('ADMM fails!');
end

dual_poly_coeffs = (Z - X)/tau; % coefficients of the dual polynomial
Tu = toeplitz(conj(u));




function T = toeplitz_adjoint(A)
N = size(A,1);
T = zeros(N,1);
T(1) = sum(diag(A));
for n = 1:(N-1)
    T(n+1) = sum(diag(A,n));
end
